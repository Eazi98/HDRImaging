/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: DCA_TMO_terminate.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 11-Jan-2023 23:04:39
 */

/* Include Files */
#include "DCA_TMO_terminate.h"
#include "DCA_TMO_data.h"
#include "rt_nonfinite.h"
#include "omp.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void DCA_TMO_terminate(void)
{
  omp_destroy_nest_lock(&DCA_TMO_nestLockGlobal);
  isInitialized_DCA_TMO = false;
}

/*
 * File trailer for DCA_TMO_terminate.c
 *
 * [EOF]
 */
