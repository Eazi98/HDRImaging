/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: DCA_TMO_data.h
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 09-Jan-2023 22:24:29
 */

#ifndef DCA_TMO_DATA_H
#define DCA_TMO_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include "omp.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern omp_nest_lock_t DCA_TMO_nestLockGlobal;
extern boolean_T isInitialized_DCA_TMO;

#endif
/*
 * File trailer for DCA_TMO_data.h
 *
 * [EOF]
 */
