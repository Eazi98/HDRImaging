/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: DCA_TMO_data.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 09-Jan-2023 22:24:29
 */

/* Include Files */
#include "DCA_TMO_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
omp_nest_lock_t DCA_TMO_nestLockGlobal;

boolean_T isInitialized_DCA_TMO = false;

/*
 * File trailer for DCA_TMO_data.c
 *
 * [EOF]
 */
