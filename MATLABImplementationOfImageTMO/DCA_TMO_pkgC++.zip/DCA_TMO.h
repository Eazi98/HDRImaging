//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: DCA_TMO.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 06-Jan-2023 00:48:44
//

#ifndef DCA_TMO_H
#define DCA_TMO_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include "omp.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern omp_nest_lock_t DCA_TMO_nestLockGlobal;

// Function Declarations
extern void DCA_TMO(coder::array<double, 3U> &hdrImg,
                    coder::array<double, 3U> &ldrImg);

extern void DCA_TMO_initialize();

extern void DCA_TMO_terminate();

#endif
//
// File trailer for DCA_TMO.h
//
// [EOF]
//
