//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: DCA_TMO_types.h
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 06-Jan-2023 00:48:44
//

#ifndef DCA_TMO_TYPES_H
#define DCA_TMO_TYPES_H

// Include Files
#include "rtwtypes.h"
#define MAX_THREADS omp_get_max_threads()

#endif
//
// File trailer for DCA_TMO_types.h
//
// [EOF]
//
