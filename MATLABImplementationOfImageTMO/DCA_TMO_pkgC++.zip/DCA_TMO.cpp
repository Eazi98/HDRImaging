//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: DCA_TMO.cpp
//
// MATLAB Coder version            : 5.5
// C/C++ source code generated on  : 06-Jan-2023 00:48:44
//

// Include Files
#include "DCA_TMO.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "libmwimfilter.h"
#include "libmwippfilter.h"
#include "omp.h"
#include <algorithm>
#include <cmath>
#include <cstring>

// Variable Definitions
omp_nest_lock_t DCA_TMO_nestLockGlobal;

static boolean_T isInitialized_DCA_TMO{false};

// Function Declarations
static void binary_expand_op(coder::array<double, 3U> &in1,
                             const coder::array<double, 3U> &in2,
                             const coder::array<double, 2U> &in3,
                             const coder::array<double, 2U> &in4);

static void binary_expand_op(coder::array<double, 2U> &in1,
                             const coder::array<double, 2U> &in2);

static void binary_expand_op(coder::array<double, 2U> &in1, double in2,
                             double in3, double in4,
                             const coder::array<double, 2U> &in5);

static void binary_expand_op(coder::array<double, 3U> &in1,
                             const coder::array<double, 2U> &in2);

namespace coder {
static void imfilter(::coder::array<double, 2U> &varargin_1);

namespace internal {
static void b_svd(const double A[81], double U[81], double s[9], double V[81]);

namespace blas {
static void b_xaxpy(int n, double a, const double x[9], int ix0, double y[81],
                    int iy0);

static double b_xnrm2(int n, const double x[9], int ix0);

static void xaxpy(int n, double a, const double x[81], int ix0, double y[9],
                  int iy0);

static void xaxpy(int n, double a, int ix0, double y[81], int iy0);

static double xdotc(int n, const double x[81], int ix0, const double y[81],
                    int iy0);

static double xnrm2(int n, const double x[81], int ix0);

static void xrot(double x[81], int ix0, int iy0, double c, double s);

static void xrotg(double *a, double *b, double *c, double *s);

static void xswap(double x[81], int ix0, int iy0);

} // namespace blas
static void expand_power(const ::coder::array<double, 3U> &a,
                         const ::coder::array<double, 2U> &b,
                         ::coder::array<double, 3U> &c);

static double maximum(const ::coder::array<double, 1U> &x);

static void merge(::coder::array<int, 2U> &idx, ::coder::array<double, 2U> &x,
                  int offset, int np, int nq, ::coder::array<int, 1U> &iwork,
                  ::coder::array<double, 1U> &xwork);

static void merge(::coder::array<int, 1U> &idx, ::coder::array<double, 1U> &x,
                  int offset, int np, int nq, ::coder::array<int, 1U> &iwork,
                  ::coder::array<double, 1U> &xwork);

static void merge_block(::coder::array<int, 2U> &idx,
                        ::coder::array<double, 2U> &x, int offset, int n,
                        int preSortLevel, ::coder::array<int, 1U> &iwork,
                        ::coder::array<double, 1U> &xwork);

static void merge_block(::coder::array<int, 1U> &idx,
                        ::coder::array<double, 1U> &x, int offset, int n,
                        int preSortLevel, ::coder::array<int, 1U> &iwork,
                        ::coder::array<double, 1U> &xwork);

static double minimum(const ::coder::array<double, 1U> &x);

static void quickselect(::coder::array<double, 2U> &v, int n, int vlen,
                        double *vn, int *nfirst, int *nlast);

static void sort(::coder::array<double, 1U> &x);

static void sort(::coder::array<double, 2U> &x);

static int thirdOfFive(const ::coder::array<double, 2U> &v, int ia, int ib);

} // namespace internal
static void interp1(const double varargin_1[55],
                    const ::coder::array<double, 2U> &varargin_3,
                    ::coder::array<double, 2U> &Vq);

static void interp1Linear(const double y[55],
                          const ::coder::array<double, 2U> &xi,
                          ::coder::array<double, 2U> &yi,
                          const double varargin_1[55]);

static double mean(const ::coder::array<double, 1U> &x);

static double median(const ::coder::array<double, 2U> &x);

static void padImage(const ::coder::array<double, 2U> &a_tmp,
                     const double pad[2], ::coder::array<double, 2U> &a);

static void svd(const double A[81], double U[81], double S[81], double V[81]);

} // namespace coder
static double rt_powd_snf(double u0, double u1);

static double tvi(double intensity);

// Function Definitions
//
// Arguments    : coder::array<double, 3U> &in1
//                const coder::array<double, 2U> &in2
// Return Type  : void
//
static void binary_expand_op(coder::array<double, 3U> &in1,
                             const coder::array<double, 2U> &in2)
{
  coder::array<double, 3U> b_in1;
  int i;
  int i1;
  int in2_idx_0;
  int in2_idx_1;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  in2_idx_0 = in2.size(0);
  in2_idx_1 = in2.size(1);
  if (in2_idx_0 == 1) {
    i = in1.size(0);
  } else {
    i = in2_idx_0;
  }
  if (in2_idx_1 == 1) {
    i1 = in1.size(1);
  } else {
    i1 = in2_idx_1;
  }
  b_in1.set_size(i, i1, 3);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2_idx_0 != 1);
  stride_1_1 = (in2_idx_1 != 1);
  if (in2_idx_1 == 1) {
    in2_idx_1 = in1.size(1);
  }
  for (i = 0; i < 3; i++) {
    int aux_0_1;
    int aux_1_1;
    aux_0_1 = 0;
    aux_1_1 = 0;
    for (i1 = 0; i1 < in2_idx_1; i1++) {
      if (in2_idx_0 == 1) {
        loop_ub = in1.size(0);
      } else {
        loop_ub = in2_idx_0;
      }
      for (int i2{0}; i2 < loop_ub; i2++) {
        b_in1[(i2 + b_in1.size(0) * i1) + b_in1.size(0) * b_in1.size(1) * i] =
            in1[(i2 * stride_0_0 + in1.size(0) * aux_0_1) +
                in1.size(0) * in1.size(1) * i] *
            in2[i2 * stride_1_0 + in2_idx_0 * aux_1_1];
      }
      aux_1_1 += stride_1_1;
      aux_0_1 += stride_0_1;
    }
  }
  in1.set_size(b_in1.size(0), b_in1.size(1), 3);
  in2_idx_1 = b_in1.size(1);
  for (i = 0; i < 3; i++) {
    for (i1 = 0; i1 < in2_idx_1; i1++) {
      loop_ub = b_in1.size(0);
      for (int i2{0}; i2 < loop_ub; i2++) {
        in1[(i2 + in1.size(0) * i1) + in1.size(0) * in1.size(1) * i] =
            b_in1[(i2 + b_in1.size(0) * i1) +
                  b_in1.size(0) * b_in1.size(1) * i];
      }
    }
  }
}

//
// Arguments    : coder::array<double, 2U> &in1
//                double in2
//                double in3
//                double in4
//                const coder::array<double, 2U> &in5
// Return Type  : void
//
static void binary_expand_op(coder::array<double, 2U> &in1, double in2,
                             double in3, double in4,
                             const coder::array<double, 2U> &in5)
{
  coder::array<double, 2U> r;
  double b_in3;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int i;
  int i1;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  b_in3 = in3 - in4;
  if (in5.size(0) == 1) {
    i = in1.size(0);
  } else {
    i = in5.size(0);
  }
  if (in5.size(1) == 1) {
    i1 = in1.size(1);
  } else {
    i1 = in5.size(1);
  }
  r.set_size(i, i1);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in5.size(0) != 1);
  stride_1_1 = (in5.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  if (in5.size(1) == 1) {
    loop_ub = in1.size(1);
  } else {
    loop_ub = in5.size(1);
  }
  for (i = 0; i < loop_ub; i++) {
    i1 = in5.size(0);
    if (i1 == 1) {
      b_loop_ub = in1.size(0);
    } else {
      b_loop_ub = i1;
    }
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      r[i1 + r.size(0) * i] =
          (255.0 * (in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] - in2) /
               b_in3 +
           1.0) *
              0.35 +
          in5[i1 * stride_1_0 + in5.size(0) * aux_1_1] * 0.65;
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(r.size(0), r.size(1));
  loop_ub = r.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_loop_ub = r.size(0);
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = r[i1 + r.size(0) * i];
    }
  }
}

//
// Arguments    : coder::array<double, 3U> &in1
//                const coder::array<double, 3U> &in2
//                const coder::array<double, 2U> &in3
//                const coder::array<double, 2U> &in4
// Return Type  : void
//
static void binary_expand_op(coder::array<double, 3U> &in1,
                             const coder::array<double, 3U> &in2,
                             const coder::array<double, 2U> &in3,
                             const coder::array<double, 2U> &in4)
{
  coder::array<double, 3U> b_in2;
  int i;
  int i1;
  int in3_idx_0;
  int in3_idx_1;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  in3_idx_0 = in3.size(0);
  in3_idx_1 = in3.size(1);
  if (in3_idx_0 == 1) {
    i = in2.size(0);
  } else {
    i = in3_idx_0;
  }
  if (in3_idx_1 == 1) {
    i1 = in2.size(1);
  } else {
    i1 = in3_idx_1;
  }
  b_in2.set_size(i, i1, 3);
  stride_0_0 = (in2.size(0) != 1);
  stride_0_1 = (in2.size(1) != 1);
  stride_1_0 = (in3_idx_0 != 1);
  stride_1_1 = (in3_idx_1 != 1);
  if (in3_idx_1 == 1) {
    in3_idx_1 = in2.size(1);
  }
  for (i = 0; i < 3; i++) {
    int aux_0_1;
    int aux_1_1;
    aux_0_1 = 0;
    aux_1_1 = 0;
    for (i1 = 0; i1 < in3_idx_1; i1++) {
      int loop_ub;
      if (in3_idx_0 == 1) {
        loop_ub = in2.size(0);
      } else {
        loop_ub = in3_idx_0;
      }
      for (int i2{0}; i2 < loop_ub; i2++) {
        b_in2[(i2 + b_in2.size(0) * i1) + b_in2.size(0) * b_in2.size(1) * i] =
            in2[(i2 * stride_0_0 + in2.size(0) * aux_0_1) +
                in2.size(0) * in2.size(1) * i] /
            in3[i2 * stride_1_0 + in3_idx_0 * aux_1_1];
      }
      aux_1_1 += stride_1_1;
      aux_0_1 += stride_0_1;
    }
  }
  coder::internal::expand_power(b_in2, in4, in1);
}

//
// Arguments    : coder::array<double, 2U> &in1
//                const coder::array<double, 2U> &in2
// Return Type  : void
//
static void binary_expand_op(coder::array<double, 2U> &in1,
                             const coder::array<double, 2U> &in2)
{
  coder::array<double, 2U> b_in1;
  int aux_0_1;
  int aux_1_1;
  int b_loop_ub;
  int i;
  int i1;
  int loop_ub;
  int stride_0_0;
  int stride_0_1;
  int stride_1_0;
  int stride_1_1;
  if (in2.size(0) == 1) {
    i = in1.size(0);
  } else {
    i = in2.size(0);
  }
  if (in2.size(1) == 1) {
    i1 = in1.size(1);
  } else {
    i1 = in2.size(1);
  }
  b_in1.set_size(i, i1);
  stride_0_0 = (in1.size(0) != 1);
  stride_0_1 = (in1.size(1) != 1);
  stride_1_0 = (in2.size(0) != 1);
  stride_1_1 = (in2.size(1) != 1);
  aux_0_1 = 0;
  aux_1_1 = 0;
  if (in2.size(1) == 1) {
    loop_ub = in1.size(1);
  } else {
    loop_ub = in2.size(1);
  }
  for (i = 0; i < loop_ub; i++) {
    i1 = in2.size(0);
    if (i1 == 1) {
      b_loop_ub = in1.size(0);
    } else {
      b_loop_ub = i1;
    }
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      b_in1[i1 + b_in1.size(0) * i] =
          in1[i1 * stride_0_0 + in1.size(0) * aux_0_1] +
          3.0 * in2[i1 * stride_1_0 + in2.size(0) * aux_1_1];
    }
    aux_1_1 += stride_1_1;
    aux_0_1 += stride_0_1;
  }
  in1.set_size(b_in1.size(0), b_in1.size(1));
  loop_ub = b_in1.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_loop_ub = b_in1.size(0);
    for (i1 = 0; i1 < b_loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = b_in1[i1 + b_in1.size(0) * i];
    }
  }
}

//
// Arguments    : ::coder::array<double, 2U> &varargin_1
// Return Type  : void
//
namespace coder {
static void imfilter(::coder::array<double, 2U> &varargin_1)
{
  static const double b_x[81]{-3.4536032619442708E-12, -8.1906882011251731E-10,
                              -4.0717697696829158E-8,  -4.2428815204386648E-7,
                              -9.2673052019452823E-7,  -4.2428815204386648E-7,
                              -4.0717697696829158E-8,  -8.1906882011251731E-10,
                              -3.4536032619442708E-12, -8.1906882011251731E-10,
                              -1.9425327135208133E-7,  -9.65675069311889E-6,
                              -0.00010062441064619439, -0.00021977728197372114,
                              -0.00010062441064619439, -9.65675069311889E-6,
                              -1.9425327135208133E-7,  -8.1906882011251731E-10,
                              -4.0717697696829158E-8,  -9.65675069311889E-6,
                              -0.00047998867375253048, -0.00497423370067001,
                              -0.0107185279736246,     -0.00497423370067001,
                              -0.00047998867375253048, -9.65675069311889E-6,
                              -4.0717697696829158E-8,  -4.2428815204386648E-7,
                              -0.00010062441064619439, -0.00497423370067001,
                              -0.040793629460149305,   -0.030121274736625389,
                              -0.040793629460149305,   -0.00497423370067001,
                              -0.00010062441064619439, -4.2428815204386648E-7,
                              -9.2673052019452823E-7,  -0.00021977728197372114,
                              -0.0107185279736246,     -0.030121274736625389,
                              0.370017121948906,       -0.030121274736625389,
                              -0.0107185279736246,     -0.00021977728197372114,
                              -9.2673052019452823E-7,  -4.2428815204386648E-7,
                              -0.00010062441064619439, -0.00497423370067001,
                              -0.040793629460149305,   -0.030121274736625389,
                              -0.040793629460149305,   -0.00497423370067001,
                              -0.00010062441064619439, -4.2428815204386648E-7,
                              -4.0717697696829158E-8,  -9.65675069311889E-6,
                              -0.00047998867375253048, -0.00497423370067001,
                              -0.0107185279736246,     -0.00497423370067001,
                              -0.00047998867375253048, -9.65675069311889E-6,
                              -4.0717697696829158E-8,  -8.1906882011251731E-10,
                              -1.9425327135208133E-7,  -9.65675069311889E-6,
                              -0.00010062441064619439, -0.00021977728197372114,
                              -0.00010062441064619439, -9.65675069311889E-6,
                              -1.9425327135208133E-7,  -8.1906882011251731E-10,
                              -3.4536032619442708E-12, -8.1906882011251731E-10,
                              -4.0717697696829158E-8,  -4.2428815204386648E-7,
                              -9.2673052019452823E-7,  -4.2428815204386648E-7,
                              -4.0717697696829158E-8,  -8.1906882011251731E-10,
                              -3.4536032619442708E-12};
  static const double h[81]{-3.4536032619442708E-12, -8.1906882011251731E-10,
                            -4.0717697696829158E-8,  -4.2428815204386648E-7,
                            -9.2673052019452823E-7,  -4.2428815204386648E-7,
                            -4.0717697696829158E-8,  -8.1906882011251731E-10,
                            -3.4536032619442708E-12, -8.1906882011251731E-10,
                            -1.9425327135208133E-7,  -9.65675069311889E-6,
                            -0.00010062441064619439, -0.00021977728197372114,
                            -0.00010062441064619439, -9.65675069311889E-6,
                            -1.9425327135208133E-7,  -8.1906882011251731E-10,
                            -4.0717697696829158E-8,  -9.65675069311889E-6,
                            -0.00047998867375253048, -0.00497423370067001,
                            -0.0107185279736246,     -0.00497423370067001,
                            -0.00047998867375253048, -9.65675069311889E-6,
                            -4.0717697696829158E-8,  -4.2428815204386648E-7,
                            -0.00010062441064619439, -0.00497423370067001,
                            -0.040793629460149305,   -0.030121274736625389,
                            -0.040793629460149305,   -0.00497423370067001,
                            -0.00010062441064619439, -4.2428815204386648E-7,
                            -9.2673052019452823E-7,  -0.00021977728197372114,
                            -0.0107185279736246,     -0.030121274736625389,
                            0.370017121948906,       -0.030121274736625389,
                            -0.0107185279736246,     -0.00021977728197372114,
                            -9.2673052019452823E-7,  -4.2428815204386648E-7,
                            -0.00010062441064619439, -0.00497423370067001,
                            -0.040793629460149305,   -0.030121274736625389,
                            -0.040793629460149305,   -0.00497423370067001,
                            -0.00010062441064619439, -4.2428815204386648E-7,
                            -4.0717697696829158E-8,  -9.65675069311889E-6,
                            -0.00047998867375253048, -0.00497423370067001,
                            -0.0107185279736246,     -0.00497423370067001,
                            -0.00047998867375253048, -9.65675069311889E-6,
                            -4.0717697696829158E-8,  -8.1906882011251731E-10,
                            -1.9425327135208133E-7,  -9.65675069311889E-6,
                            -0.00010062441064619439, -0.00021977728197372114,
                            -0.00010062441064619439, -9.65675069311889E-6,
                            -1.9425327135208133E-7,  -8.1906882011251731E-10,
                            -3.4536032619442708E-12, -8.1906882011251731E-10,
                            -4.0717697696829158E-8,  -4.2428815204386648E-7,
                            -9.2673052019452823E-7,  -4.2428815204386648E-7,
                            -4.0717697696829158E-8,  -8.1906882011251731E-10,
                            -3.4536032619442708E-12};
  array<double, 2U> a;
  double outSizeT[2];
  double startT[2];
  signed char b_tmp_data[9];
  signed char tmp_data[9];
  outSizeT[0] = varargin_1.size(0);
  startT[0] = 4.0;
  outSizeT[1] = varargin_1.size(1);
  startT[1] = 4.0;
  if ((varargin_1.size(0) != 0) && (varargin_1.size(1) != 0)) {
    double a__1[81];
    double a__2[81];
    double s[81];
    double b_s[9];
    double d;
    double tol;
    int b_i;
    int i;
    int idx;
    boolean_T x[9];
    svd(h, a__1, s, a__2);
    for (i = 0; i < 9; i++) {
      b_s[i] = s[i + 9 * i];
    }
    if (!std::isnan(b_s[0])) {
      idx = 1;
    } else {
      boolean_T exitg1;
      idx = 0;
      i = 2;
      exitg1 = false;
      while ((!exitg1) && (i <= 9)) {
        if (!std::isnan(b_s[i - 1])) {
          idx = i;
          exitg1 = true;
        } else {
          i++;
        }
      }
    }
    if (idx == 0) {
      tol = b_s[0];
    } else {
      tol = b_s[idx - 1];
      b_i = idx + 1;
      for (i = b_i; i < 10; i++) {
        d = b_s[i - 1];
        if (tol < d) {
          tol = d;
        }
      }
    }
    tol = 9.0 * tol * 2.2204460492503131E-16;
    for (i = 0; i < 9; i++) {
      x[i] = (b_s[i] > tol);
    }
    idx = x[0];
    for (i = 0; i < 8; i++) {
      idx += x[i + 1];
    }
    if (idx == 1) {
      double hcol[9];
      double nonzero_h_data[9];
      double connDimsT[2];
      double out_size_row[2];
      double padSizeT[2];
      int trueCount;
      boolean_T tooBig;
      padImage(varargin_1, startT, a);
      svd(h, a__1, s, a__2);
      for (i = 0; i < 9; i++) {
        b_s[i] = s[i + 9 * i];
      }
      tol = std::sqrt(b_s[0]);
      out_size_row[0] = a.size(0);
      out_size_row[1] = varargin_1.size(1);
      trueCount = 0;
      idx = 0;
      for (i = 0; i < 9; i++) {
        hcol[i] = a__1[i] * tol;
        d = a__2[i] * tol;
        b_s[i] = d;
        if (d != 0.0) {
          trueCount++;
          tmp_data[idx] = static_cast<signed char>(i + 1);
          idx++;
        }
      }
      for (b_i = 0; b_i < trueCount; b_i++) {
        nonzero_h_data[b_i] = b_s[tmp_data[b_i] - 1];
      }
      for (i = 0; i < 9; i++) {
        x[i] = (b_s[i] != 0.0);
      }
      tooBig = true;
      if ((a.size(0) <= 65500) || (!(out_size_row[1] > 65500.0))) {
        tooBig = false;
      }
      if ((static_cast<double>(trueCount) / 9.0 > 0.05) && (!tooBig)) {
        tooBig = true;
      } else {
        tooBig = false;
      }
      varargin_1.set_size(a.size(0), static_cast<int>(out_size_row[1]));
      if (tooBig) {
        padSizeT[0] = a.size(0);
        startT[0] = 1.0;
        padSizeT[1] = a.size(1);
        startT[1] = 9.0;
        ippfilter_real64(&a[0], &varargin_1[0], &out_size_row[0], 2.0,
                         &padSizeT[0], &b_s[0], &startT[0], false);
      } else {
        padSizeT[0] = a.size(0);
        connDimsT[0] = 1.0;
        startT[0] = 0.0;
        padSizeT[1] = a.size(1);
        connDimsT[1] = 9.0;
        startT[1] = 4.0;
        imfilter_real64(&a[0], &varargin_1[0], 2.0, &out_size_row[0], 2.0,
                        &padSizeT[0], &nonzero_h_data[0],
                        static_cast<double>(trueCount), &x[0], 2.0,
                        &connDimsT[0], &startT[0], 2.0, true, false);
      }
      trueCount = 0;
      idx = 0;
      for (i = 0; i < 9; i++) {
        if (hcol[i] != 0.0) {
          trueCount++;
          b_tmp_data[idx] = static_cast<signed char>(i + 1);
          idx++;
        }
      }
      for (b_i = 0; b_i < trueCount; b_i++) {
        nonzero_h_data[b_i] = hcol[b_tmp_data[b_i] - 1];
      }
      for (i = 0; i < 9; i++) {
        x[i] = (hcol[i] != 0.0);
      }
      tooBig = true;
      if ((outSizeT[0] <= 65500.0) || (!(outSizeT[1] > 65500.0))) {
        tooBig = false;
      }
      if ((static_cast<double>(trueCount) / 9.0 > 0.05) && (!tooBig)) {
        tooBig = true;
      } else {
        tooBig = false;
      }
      a.set_size(varargin_1.size(0), varargin_1.size(1));
      idx = varargin_1.size(0) * varargin_1.size(1);
      for (b_i = 0; b_i < idx; b_i++) {
        a[b_i] = varargin_1[b_i];
      }
      varargin_1.set_size(static_cast<int>(outSizeT[0]),
                          static_cast<int>(outSizeT[1]));
      if (tooBig) {
        padSizeT[0] = a.size(0);
        startT[0] = 9.0;
        padSizeT[1] = a.size(1);
        startT[1] = 1.0;
        ippfilter_real64(&a[0], &varargin_1[0], &outSizeT[0], 2.0, &padSizeT[0],
                         &hcol[0], &startT[0], false);
      } else {
        padSizeT[0] = a.size(0);
        connDimsT[0] = 9.0;
        startT[0] = 4.0;
        padSizeT[1] = a.size(1);
        connDimsT[1] = 1.0;
        startT[1] = 0.0;
        imfilter_real64(&a[0], &varargin_1[0], 2.0, &outSizeT[0], 2.0,
                        &padSizeT[0], &nonzero_h_data[0],
                        static_cast<double>(trueCount), &x[0], 2.0,
                        &connDimsT[0], &startT[0], 2.0, true, false);
      }
    } else {
      boolean_T tooBig;
      padImage(varargin_1, startT, a);
      tooBig = true;
      if ((outSizeT[0] <= 65500.0) || (!(outSizeT[1] > 65500.0))) {
        tooBig = false;
      }
      varargin_1.set_size(static_cast<int>(outSizeT[0]),
                          static_cast<int>(outSizeT[1]));
      if (!tooBig) {
        double padSizeT[2];
        padSizeT[0] = a.size(0);
        startT[0] = 9.0;
        padSizeT[1] = a.size(1);
        startT[1] = 9.0;
        ippfilter_real64(&a[0], &varargin_1[0], &outSizeT[0], 2.0, &padSizeT[0],
                         &h[0], &startT[0], false);
      } else {
        double padSizeT[2];
        boolean_T conn[81];
        padSizeT[0] = a.size(0);
        padSizeT[1] = a.size(1);
        for (b_i = 0; b_i < 81; b_i++) {
          conn[b_i] = true;
        }
        double connDimsT[2];
        connDimsT[0] = 9.0;
        connDimsT[1] = 9.0;
        imfilter_real64(&a[0], &varargin_1[0], 2.0, &outSizeT[0], 2.0,
                        &padSizeT[0], &b_x[0], 81.0, &conn[0], 2.0,
                        &connDimsT[0], &startT[0], 2.0, true, false);
      }
    }
  }
}

//
// Arguments    : const double A[81]
//                double U[81]
//                double s[9]
//                double V[81]
// Return Type  : void
//
namespace internal {
static void b_svd(const double A[81], double U[81], double s[9], double V[81])
{
  double b_A[81];
  double e[9];
  double work[9];
  double nrm;
  double rt;
  double sm;
  double snorm;
  double sqds;
  int ii;
  int jj;
  int m;
  int qjj;
  int qp1;
  int qp1jj;
  int qq;
  std::copy(&A[0], &A[81], &b_A[0]);
  std::memset(&s[0], 0, 9U * sizeof(double));
  std::memset(&e[0], 0, 9U * sizeof(double));
  std::memset(&work[0], 0, 9U * sizeof(double));
  std::memset(&U[0], 0, 81U * sizeof(double));
  std::memset(&V[0], 0, 81U * sizeof(double));
  for (int q{0}; q < 8; q++) {
    boolean_T apply_transform;
    qp1 = q + 2;
    qq = (q + 9 * q) + 1;
    apply_transform = false;
    nrm = blas::xnrm2(9 - q, b_A, qq);
    if (nrm > 0.0) {
      apply_transform = true;
      if (b_A[qq - 1] < 0.0) {
        nrm = -nrm;
      }
      s[q] = nrm;
      if (std::abs(nrm) >= 1.0020841800044864E-292) {
        nrm = 1.0 / nrm;
        qp1jj = (qq - q) + 8;
        for (int k{qq}; k <= qp1jj; k++) {
          b_A[k - 1] *= nrm;
        }
      } else {
        qp1jj = (qq - q) + 8;
        for (int k{qq}; k <= qp1jj; k++) {
          b_A[k - 1] /= s[q];
        }
      }
      b_A[qq - 1]++;
      s[q] = -s[q];
    } else {
      s[q] = 0.0;
    }
    for (jj = qp1; jj < 10; jj++) {
      qjj = q + 9 * (jj - 1);
      if (apply_transform) {
        blas::xaxpy(
            9 - q,
            -(blas::xdotc(9 - q, b_A, qq, b_A, qjj + 1) / b_A[q + 9 * q]), qq,
            b_A, qjj + 1);
      }
      e[jj - 1] = b_A[qjj];
    }
    for (ii = q + 1; ii < 10; ii++) {
      qjj = (ii + 9 * q) - 1;
      U[qjj] = b_A[qjj];
    }
    if (q + 1 <= 7) {
      nrm = blas::b_xnrm2(8 - q, e, q + 2);
      if (nrm == 0.0) {
        e[q] = 0.0;
      } else {
        if (e[q + 1] < 0.0) {
          e[q] = -nrm;
        } else {
          e[q] = nrm;
        }
        nrm = e[q];
        if (std::abs(e[q]) >= 1.0020841800044864E-292) {
          nrm = 1.0 / e[q];
          for (int k{qp1}; k < 10; k++) {
            e[k - 1] *= nrm;
          }
        } else {
          for (int k{qp1}; k < 10; k++) {
            e[k - 1] /= nrm;
          }
        }
        e[q + 1]++;
        e[q] = -e[q];
        for (ii = qp1; ii < 10; ii++) {
          work[ii - 1] = 0.0;
        }
        for (jj = qp1; jj < 10; jj++) {
          blas::xaxpy(8 - q, e[jj - 1], b_A, (q + 9 * (jj - 1)) + 2, work,
                      q + 2);
        }
        for (jj = qp1; jj < 10; jj++) {
          blas::b_xaxpy(8 - q, -e[jj - 1] / e[q + 1], work, q + 2, b_A,
                        (q + 9 * (jj - 1)) + 2);
        }
      }
      for (ii = qp1; ii < 10; ii++) {
        V[(ii + 9 * q) - 1] = e[ii - 1];
      }
    }
  }
  m = 7;
  s[8] = b_A[80];
  e[7] = b_A[79];
  e[8] = 0.0;
  std::memset(&U[72], 0, 9U * sizeof(double));
  U[80] = 1.0;
  for (int q{7}; q >= 0; q--) {
    qp1 = q + 2;
    qq = q + 9 * q;
    if (s[q] != 0.0) {
      for (jj = qp1; jj < 10; jj++) {
        qjj = (q + 9 * (jj - 1)) + 1;
        blas::xaxpy(9 - q, -(blas::xdotc(9 - q, U, qq + 1, U, qjj) / U[qq]),
                    qq + 1, U, qjj);
      }
      for (ii = q + 1; ii < 10; ii++) {
        qjj = (ii + 9 * q) - 1;
        U[qjj] = -U[qjj];
      }
      U[qq]++;
      for (ii = 0; ii < q; ii++) {
        U[ii + 9 * q] = 0.0;
      }
    } else {
      std::memset(&U[q * 9], 0, 9U * sizeof(double));
      U[qq] = 1.0;
    }
  }
  for (int q{8}; q >= 0; q--) {
    if ((q + 1 <= 7) && (e[q] != 0.0)) {
      qp1 = q + 2;
      qjj = (q + 9 * q) + 2;
      for (jj = qp1; jj < 10; jj++) {
        qp1jj = (q + 9 * (jj - 1)) + 2;
        blas::xaxpy(8 - q, -(blas::xdotc(8 - q, V, qjj, V, qp1jj) / V[qjj - 1]),
                    qjj, V, qp1jj);
      }
    }
    std::memset(&V[q * 9], 0, 9U * sizeof(double));
    V[q + 9 * q] = 1.0;
  }
  qq = 0;
  snorm = 0.0;
  for (int q{0}; q < 9; q++) {
    nrm = s[q];
    if (nrm != 0.0) {
      rt = std::abs(nrm);
      nrm /= rt;
      s[q] = rt;
      if (q + 1 < 9) {
        e[q] /= nrm;
      }
      qjj = 9 * q;
      qp1jj = qjj + 9;
      for (int k{qjj + 1}; k <= qp1jj; k++) {
        U[k - 1] *= nrm;
      }
    }
    if (q + 1 < 9) {
      nrm = e[q];
      if (nrm != 0.0) {
        rt = std::abs(nrm);
        nrm = rt / nrm;
        e[q] = rt;
        s[q + 1] *= nrm;
        qjj = 9 * (q + 1);
        qp1jj = qjj + 9;
        for (int k{qjj + 1}; k <= qp1jj; k++) {
          V[k - 1] *= nrm;
        }
      }
    }
    snorm = std::fmax(snorm, std::fmax(std::abs(s[q]), std::abs(e[q])));
  }
  while ((m + 2 > 0) && (qq < 75)) {
    boolean_T exitg1;
    jj = m + 1;
    ii = m + 1;
    exitg1 = false;
    while (!(exitg1 || (ii == 0))) {
      nrm = std::abs(e[ii - 1]);
      if ((nrm <=
           2.2204460492503131E-16 * (std::abs(s[ii - 1]) + std::abs(s[ii]))) ||
          (nrm <= 1.0020841800044864E-292) ||
          ((qq > 20) && (nrm <= 2.2204460492503131E-16 * snorm))) {
        e[ii - 1] = 0.0;
        exitg1 = true;
      } else {
        ii--;
      }
    }
    if (ii == m + 1) {
      qjj = 4;
    } else {
      qp1jj = m + 2;
      qjj = m + 2;
      exitg1 = false;
      while ((!exitg1) && (qjj >= ii)) {
        qp1jj = qjj;
        if (qjj == ii) {
          exitg1 = true;
        } else {
          nrm = 0.0;
          if (qjj < m + 2) {
            nrm = std::abs(e[qjj - 1]);
          }
          if (qjj > ii + 1) {
            nrm += std::abs(e[qjj - 2]);
          }
          rt = std::abs(s[qjj - 1]);
          if ((rt <= 2.2204460492503131E-16 * nrm) ||
              (rt <= 1.0020841800044864E-292)) {
            s[qjj - 1] = 0.0;
            exitg1 = true;
          } else {
            qjj--;
          }
        }
      }
      if (qp1jj == ii) {
        qjj = 3;
      } else if (qp1jj == m + 2) {
        qjj = 1;
      } else {
        qjj = 2;
        ii = qp1jj;
      }
    }
    switch (qjj) {
    case 1: {
      rt = e[m];
      e[m] = 0.0;
      for (int k{jj}; k >= ii + 1; k--) {
        blas::xrotg(&s[k - 1], &rt, &sm, &sqds);
        if (k > ii + 1) {
          double b;
          b = e[k - 2];
          rt = -sqds * b;
          e[k - 2] = b * sm;
        }
        blas::xrot(V, 9 * (k - 1) + 1, 9 * (m + 1) + 1, sm, sqds);
      }
    } break;
    case 2: {
      rt = e[ii - 1];
      e[ii - 1] = 0.0;
      for (int k{ii + 1}; k <= m + 2; k++) {
        double b;
        blas::xrotg(&s[k - 1], &rt, &sm, &sqds);
        b = e[k - 1];
        rt = -sqds * b;
        e[k - 1] = b * sm;
        blas::xrot(U, 9 * (k - 1) + 1, 9 * (ii - 1) + 1, sm, sqds);
      }
    } break;
    case 3: {
      double b;
      double scale;
      nrm = s[m + 1];
      scale = std::fmax(
          std::fmax(std::fmax(std::fmax(std::abs(nrm), std::abs(s[m])),
                              std::abs(e[m])),
                    std::abs(s[ii])),
          std::abs(e[ii]));
      sm = nrm / scale;
      nrm = s[m] / scale;
      rt = e[m] / scale;
      sqds = s[ii] / scale;
      b = ((nrm + sm) * (nrm - sm) + rt * rt) / 2.0;
      nrm = sm * rt;
      nrm *= nrm;
      if ((b != 0.0) || (nrm != 0.0)) {
        rt = std::sqrt(b * b + nrm);
        if (b < 0.0) {
          rt = -rt;
        }
        rt = nrm / (b + rt);
      } else {
        rt = 0.0;
      }
      rt += (sqds + sm) * (sqds - sm);
      nrm = sqds * (e[ii] / scale);
      for (int k{ii + 1}; k <= jj; k++) {
        blas::xrotg(&rt, &nrm, &sm, &sqds);
        if (k > ii + 1) {
          e[k - 2] = rt;
        }
        nrm = e[k - 1];
        b = s[k - 1];
        e[k - 1] = sm * nrm - sqds * b;
        rt = sqds * s[k];
        s[k] *= sm;
        blas::xrot(V, 9 * (k - 1) + 1, 9 * k + 1, sm, sqds);
        s[k - 1] = sm * b + sqds * nrm;
        blas::xrotg(&s[k - 1], &rt, &sm, &sqds);
        rt = sm * e[k - 1] + sqds * s[k];
        s[k] = -sqds * e[k - 1] + sm * s[k];
        nrm = sqds * e[k];
        e[k] *= sm;
        blas::xrot(U, 9 * (k - 1) + 1, 9 * k + 1, sm, sqds);
      }
      e[m] = rt;
      qq++;
    } break;
    default:
      if (s[ii] < 0.0) {
        s[ii] = -s[ii];
        qjj = 9 * ii;
        qp1jj = qjj + 9;
        for (int k{qjj + 1}; k <= qp1jj; k++) {
          V[k - 1] = -V[k - 1];
        }
      }
      qp1 = ii + 1;
      while ((ii + 1 < 9) && (s[ii] < s[qp1])) {
        rt = s[ii];
        s[ii] = s[qp1];
        s[qp1] = rt;
        blas::xswap(V, 9 * ii + 1, 9 * (ii + 1) + 1);
        blas::xswap(U, 9 * ii + 1, 9 * (ii + 1) + 1);
        ii = qp1;
        qp1++;
      }
      qq = 0;
      m--;
      break;
    }
  }
}

//
// Arguments    : int n
//                double a
//                const double x[9]
//                int ix0
//                double y[81]
//                int iy0
// Return Type  : void
//
namespace blas {
static void b_xaxpy(int n, double a, const double x[9], int ix0, double y[81],
                    int iy0)
{
  if (!(a == 0.0)) {
    int i;
    i = n - 1;
    for (int k{0}; k <= i; k++) {
      int i1;
      i1 = (iy0 + k) - 1;
      y[i1] += a * x[(ix0 + k) - 1];
    }
  }
}

//
// Arguments    : int n
//                const double x[9]
//                int ix0
// Return Type  : double
//
static double b_xnrm2(int n, const double x[9], int ix0)
{
  double scale;
  double y;
  int kend;
  y = 0.0;
  scale = 3.3121686421112381E-170;
  kend = (ix0 + n) - 1;
  for (int k{ix0}; k <= kend; k++) {
    double absxk;
    absxk = std::abs(x[k - 1]);
    if (absxk > scale) {
      double t;
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      double t;
      t = absxk / scale;
      y += t * t;
    }
  }
  return scale * std::sqrt(y);
}

//
// Arguments    : int n
//                double a
//                int ix0
//                double y[81]
//                int iy0
// Return Type  : void
//
static void xaxpy(int n, double a, int ix0, double y[81], int iy0)
{
  if (!(a == 0.0)) {
    int i;
    i = n - 1;
    for (int k{0}; k <= i; k++) {
      int i1;
      i1 = (iy0 + k) - 1;
      y[i1] += a * y[(ix0 + k) - 1];
    }
  }
}

//
// Arguments    : int n
//                double a
//                const double x[81]
//                int ix0
//                double y[9]
//                int iy0
// Return Type  : void
//
static void xaxpy(int n, double a, const double x[81], int ix0, double y[9],
                  int iy0)
{
  if (!(a == 0.0)) {
    int i;
    i = n - 1;
    for (int k{0}; k <= i; k++) {
      int i1;
      i1 = (iy0 + k) - 1;
      y[i1] += a * x[(ix0 + k) - 1];
    }
  }
}

//
// Arguments    : int n
//                const double x[81]
//                int ix0
//                const double y[81]
//                int iy0
// Return Type  : double
//
static double xdotc(int n, const double x[81], int ix0, const double y[81],
                    int iy0)
{
  double d;
  int i;
  d = 0.0;
  i = static_cast<unsigned char>(n);
  for (int k{0}; k < i; k++) {
    d += x[(ix0 + k) - 1] * y[(iy0 + k) - 1];
  }
  return d;
}

//
// Arguments    : int n
//                const double x[81]
//                int ix0
// Return Type  : double
//
static double xnrm2(int n, const double x[81], int ix0)
{
  double scale;
  double y;
  int kend;
  y = 0.0;
  scale = 3.3121686421112381E-170;
  kend = (ix0 + n) - 1;
  for (int k{ix0}; k <= kend; k++) {
    double absxk;
    absxk = std::abs(x[k - 1]);
    if (absxk > scale) {
      double t;
      t = scale / absxk;
      y = y * t * t + 1.0;
      scale = absxk;
    } else {
      double t;
      t = absxk / scale;
      y += t * t;
    }
  }
  return scale * std::sqrt(y);
}

//
// Arguments    : double x[81]
//                int ix0
//                int iy0
//                double c
//                double s
// Return Type  : void
//
static void xrot(double x[81], int ix0, int iy0, double c, double s)
{
  for (int k{0}; k < 9; k++) {
    double b_temp_tmp;
    double d_temp_tmp;
    int c_temp_tmp;
    int temp_tmp;
    temp_tmp = (iy0 + k) - 1;
    b_temp_tmp = x[temp_tmp];
    c_temp_tmp = (ix0 + k) - 1;
    d_temp_tmp = x[c_temp_tmp];
    x[temp_tmp] = c * b_temp_tmp - s * d_temp_tmp;
    x[c_temp_tmp] = c * d_temp_tmp + s * b_temp_tmp;
  }
}

//
// Arguments    : double *a
//                double *b
//                double *c
//                double *s
// Return Type  : void
//
static void xrotg(double *a, double *b, double *c, double *s)
{
  double absa;
  double absb;
  double roe;
  double scale;
  roe = *b;
  absa = std::abs(*a);
  absb = std::abs(*b);
  if (absa > absb) {
    roe = *a;
  }
  scale = absa + absb;
  if (scale == 0.0) {
    *s = 0.0;
    *c = 1.0;
    *a = 0.0;
    *b = 0.0;
  } else {
    double ads;
    double bds;
    ads = absa / scale;
    bds = absb / scale;
    scale *= std::sqrt(ads * ads + bds * bds);
    if (roe < 0.0) {
      scale = -scale;
    }
    *c = *a / scale;
    *s = *b / scale;
    if (absa > absb) {
      *b = *s;
    } else if (*c != 0.0) {
      *b = 1.0 / *c;
    } else {
      *b = 1.0;
    }
    *a = scale;
  }
}

//
// Arguments    : double x[81]
//                int ix0
//                int iy0
// Return Type  : void
//
static void xswap(double x[81], int ix0, int iy0)
{
  for (int k{0}; k < 9; k++) {
    double temp;
    int i;
    int temp_tmp;
    temp_tmp = (ix0 + k) - 1;
    temp = x[temp_tmp];
    i = (iy0 + k) - 1;
    x[temp_tmp] = x[i];
    x[i] = temp;
  }
}

//
// Arguments    : const ::coder::array<double, 3U> &a
//                const ::coder::array<double, 2U> &b
//                ::coder::array<double, 3U> &c
// Return Type  : void
//
} // namespace blas
static void expand_power(const ::coder::array<double, 3U> &a,
                         const ::coder::array<double, 2U> &b,
                         ::coder::array<double, 3U> &c)
{
  int b_u1;
  int u0;
  int u1;
  u0 = a.size(0);
  u1 = b.size(0);
  if (u0 <= u1) {
    u1 = u0;
  }
  u0 = a.size(1);
  b_u1 = b.size(1);
  if (u0 <= b_u1) {
    b_u1 = u0;
  }
  if (b.size(0) == 1) {
    u1 = a.size(0);
  } else if (a.size(0) == 1) {
    u1 = b.size(0);
  }
  if (b.size(1) == 1) {
    b_u1 = a.size(1);
  } else if (a.size(1) == 1) {
    b_u1 = b.size(1);
  }
  c.set_size(u1, b_u1, 3);
  u0 = a.size(0);
  u1 = b.size(0);
  if (u0 <= u1) {
    u1 = u0;
  }
  u0 = a.size(1);
  b_u1 = b.size(1);
  if (u0 <= b_u1) {
    b_u1 = u0;
  }
  if (b.size(0) == 1) {
    u1 = a.size(0);
  } else if (a.size(0) == 1) {
    u1 = b.size(0);
  }
  if (b.size(1) == 1) {
    b_u1 = a.size(1);
  } else if (a.size(1) == 1) {
    b_u1 = b.size(1);
  }
  if ((u1 != 0) && (b_u1 != 0)) {
    boolean_T b1;
    boolean_T b2;
    boolean_T b3;
    boolean_T b_b;
    b_b = (a.size(1) != 1);
    b1 = (b.size(1) != 1);
    b2 = (a.size(0) != 1);
    b3 = (b.size(0) != 1);
    for (int k{0}; k < 3; k++) {
      u0 = c.size(1) - 1;
      for (int b_k{0}; b_k <= u0; b_k++) {
        int i;
        u1 = b_b * b_k;
        b_u1 = b1 * b_k;
        i = c.size(0) - 1;
        for (int c_k{0}; c_k <= i; c_k++) {
          c[(c_k + c.size(0) * b_k) + c.size(0) * c.size(1) * k] = rt_powd_snf(
              a[(b2 * c_k + a.size(0) * u1) + a.size(0) * a.size(1) * k],
              b[b3 * c_k + b.size(0) * b_u1]);
        }
      }
    }
  }
}

//
// Arguments    : const ::coder::array<double, 1U> &x
// Return Type  : double
//
static double maximum(const ::coder::array<double, 1U> &x)
{
  double ex;
  int last;
  last = x.size(0);
  if (x.size(0) <= 2) {
    if (x.size(0) == 1) {
      ex = x[0];
    } else if ((x[0] < x[x.size(0) - 1]) ||
               (std::isnan(x[0]) && (!std::isnan(x[x.size(0) - 1])))) {
      ex = x[x.size(0) - 1];
    } else {
      ex = x[0];
    }
  } else {
    int idx;
    int k;
    if (!std::isnan(x[0])) {
      idx = 1;
    } else {
      boolean_T exitg1;
      idx = 0;
      k = 2;
      exitg1 = false;
      while ((!exitg1) && (k <= last)) {
        if (!std::isnan(x[k - 1])) {
          idx = k;
          exitg1 = true;
        } else {
          k++;
        }
      }
    }
    if (idx == 0) {
      ex = x[0];
    } else {
      ex = x[idx - 1];
      idx++;
      for (k = idx; k <= last; k++) {
        double d;
        d = x[k - 1];
        if (ex < d) {
          ex = d;
        }
      }
    }
  }
  return ex;
}

//
// Arguments    : ::coder::array<int, 2U> &idx
//                ::coder::array<double, 2U> &x
//                int offset
//                int np
//                int nq
//                ::coder::array<int, 1U> &iwork
//                ::coder::array<double, 1U> &xwork
// Return Type  : void
//
static void merge(::coder::array<int, 2U> &idx, ::coder::array<double, 2U> &x,
                  int offset, int np, int nq, ::coder::array<int, 1U> &iwork,
                  ::coder::array<double, 1U> &xwork)
{
  if (nq != 0) {
    int iout;
    int n_tmp;
    int p;
    int q;
    n_tmp = np + nq;
    for (int j{0}; j < n_tmp; j++) {
      iout = offset + j;
      iwork[j] = idx[iout];
      xwork[j] = x[iout];
    }
    p = 0;
    q = np;
    iout = offset - 1;
    int exitg1;
    do {
      exitg1 = 0;
      iout++;
      if (xwork[p] <= xwork[q]) {
        idx[iout] = iwork[p];
        x[iout] = xwork[p];
        if (p + 1 < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        idx[iout] = iwork[q];
        x[iout] = xwork[q];
        if (q + 1 < n_tmp) {
          q++;
        } else {
          q = iout - p;
          for (int j{p + 1}; j <= np; j++) {
            iout = q + j;
            idx[iout] = iwork[j - 1];
            x[iout] = xwork[j - 1];
          }
          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

//
// Arguments    : ::coder::array<int, 1U> &idx
//                ::coder::array<double, 1U> &x
//                int offset
//                int np
//                int nq
//                ::coder::array<int, 1U> &iwork
//                ::coder::array<double, 1U> &xwork
// Return Type  : void
//
static void merge(::coder::array<int, 1U> &idx, ::coder::array<double, 1U> &x,
                  int offset, int np, int nq, ::coder::array<int, 1U> &iwork,
                  ::coder::array<double, 1U> &xwork)
{
  if (nq != 0) {
    int iout;
    int n_tmp;
    int p;
    int q;
    n_tmp = np + nq;
    for (int j{0}; j < n_tmp; j++) {
      iout = offset + j;
      iwork[j] = idx[iout];
      xwork[j] = x[iout];
    }
    p = 0;
    q = np;
    iout = offset - 1;
    int exitg1;
    do {
      exitg1 = 0;
      iout++;
      if (xwork[p] <= xwork[q]) {
        idx[iout] = iwork[p];
        x[iout] = xwork[p];
        if (p + 1 < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        idx[iout] = iwork[q];
        x[iout] = xwork[q];
        if (q + 1 < n_tmp) {
          q++;
        } else {
          q = iout - p;
          for (int j{p + 1}; j <= np; j++) {
            iout = q + j;
            idx[iout] = iwork[j - 1];
            x[iout] = xwork[j - 1];
          }
          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

//
// Arguments    : ::coder::array<int, 2U> &idx
//                ::coder::array<double, 2U> &x
//                int offset
//                int n
//                int preSortLevel
//                ::coder::array<int, 1U> &iwork
//                ::coder::array<double, 1U> &xwork
// Return Type  : void
//
static void merge_block(::coder::array<int, 2U> &idx,
                        ::coder::array<double, 2U> &x, int offset, int n,
                        int preSortLevel, ::coder::array<int, 1U> &iwork,
                        ::coder::array<double, 1U> &xwork)
{
  int bLen;
  int nPairs;
  nPairs = n >> preSortLevel;
  bLen = 1 << preSortLevel;
  while (nPairs > 1) {
    int nTail;
    int tailOffset;
    if ((nPairs & 1) != 0) {
      nPairs--;
      tailOffset = bLen * nPairs;
      nTail = n - tailOffset;
      if (nTail > bLen) {
        merge(idx, x, offset + tailOffset, bLen, nTail - bLen, iwork, xwork);
      }
    }
    tailOffset = bLen << 1;
    nPairs >>= 1;
    for (nTail = 0; nTail < nPairs; nTail++) {
      merge(idx, x, offset + nTail * tailOffset, bLen, bLen, iwork, xwork);
    }
    bLen = tailOffset;
  }
  if (n > bLen) {
    merge(idx, x, offset, bLen, n - bLen, iwork, xwork);
  }
}

//
// Arguments    : ::coder::array<int, 1U> &idx
//                ::coder::array<double, 1U> &x
//                int offset
//                int n
//                int preSortLevel
//                ::coder::array<int, 1U> &iwork
//                ::coder::array<double, 1U> &xwork
// Return Type  : void
//
static void merge_block(::coder::array<int, 1U> &idx,
                        ::coder::array<double, 1U> &x, int offset, int n,
                        int preSortLevel, ::coder::array<int, 1U> &iwork,
                        ::coder::array<double, 1U> &xwork)
{
  int bLen;
  int nPairs;
  nPairs = n >> preSortLevel;
  bLen = 1 << preSortLevel;
  while (nPairs > 1) {
    int nTail;
    int tailOffset;
    if ((nPairs & 1) != 0) {
      nPairs--;
      tailOffset = bLen * nPairs;
      nTail = n - tailOffset;
      if (nTail > bLen) {
        merge(idx, x, offset + tailOffset, bLen, nTail - bLen, iwork, xwork);
      }
    }
    tailOffset = bLen << 1;
    nPairs >>= 1;
    for (nTail = 0; nTail < nPairs; nTail++) {
      merge(idx, x, offset + nTail * tailOffset, bLen, bLen, iwork, xwork);
    }
    bLen = tailOffset;
  }
  if (n > bLen) {
    merge(idx, x, offset, bLen, n - bLen, iwork, xwork);
  }
}

//
// Arguments    : const ::coder::array<double, 1U> &x
// Return Type  : double
//
static double minimum(const ::coder::array<double, 1U> &x)
{
  double ex;
  int last;
  last = x.size(0);
  if (x.size(0) <= 2) {
    if (x.size(0) == 1) {
      ex = x[0];
    } else if ((x[0] > x[x.size(0) - 1]) ||
               (std::isnan(x[0]) && (!std::isnan(x[x.size(0) - 1])))) {
      ex = x[x.size(0) - 1];
    } else {
      ex = x[0];
    }
  } else {
    int idx;
    int k;
    if (!std::isnan(x[0])) {
      idx = 1;
    } else {
      boolean_T exitg1;
      idx = 0;
      k = 2;
      exitg1 = false;
      while ((!exitg1) && (k <= last)) {
        if (!std::isnan(x[k - 1])) {
          idx = k;
          exitg1 = true;
        } else {
          k++;
        }
      }
    }
    if (idx == 0) {
      ex = x[0];
    } else {
      ex = x[idx - 1];
      idx++;
      for (k = idx; k <= last; k++) {
        double d;
        d = x[k - 1];
        if (ex > d) {
          ex = d;
        }
      }
    }
  }
  return ex;
}

//
// Arguments    : ::coder::array<double, 2U> &v
//                int n
//                int vlen
//                double *vn
//                int *nfirst
//                int *nlast
// Return Type  : void
//
static void quickselect(::coder::array<double, 2U> &v, int n, int vlen,
                        double *vn, int *nfirst, int *nlast)
{
  if (n > vlen) {
    *vn = rtNaN;
    *nfirst = 0;
    *nlast = 0;
  } else {
    int ia;
    int ib;
    int ilast;
    int ipiv;
    int oldnv;
    boolean_T checkspeed;
    boolean_T exitg1;
    boolean_T isslow;
    ipiv = n;
    ia = 0;
    ib = vlen - 1;
    *nfirst = 1;
    ilast = vlen - 1;
    oldnv = vlen;
    checkspeed = false;
    isslow = false;
    exitg1 = false;
    while ((!exitg1) && (ia + 1 < ib + 1)) {
      double vref;
      boolean_T guard1{false};
      vref = v[ipiv - 1];
      v[ipiv - 1] = v[ib];
      v[ib] = vref;
      ilast = ia;
      ipiv = -1;
      for (int k{ia + 1}; k <= ib; k++) {
        double d;
        double vk;
        vk = v[k - 1];
        d = v[k - 1];
        if (d == vref) {
          v[k - 1] = v[ilast];
          v[ilast] = vk;
          ipiv++;
          ilast++;
        } else if (d < vref) {
          v[k - 1] = v[ilast];
          v[ilast] = vk;
          ilast++;
        }
      }
      v[ib] = v[ilast];
      v[ilast] = vref;
      guard1 = false;
      if (n <= ilast + 1) {
        *nfirst = ilast - ipiv;
        if (n >= *nfirst) {
          exitg1 = true;
        } else {
          ib = ilast - 1;
          guard1 = true;
        }
      } else {
        ia = ilast + 1;
        guard1 = true;
      }
      if (guard1) {
        int c;
        c = (ib - ia) + 1;
        if (checkspeed) {
          isslow = (c > oldnv / 2);
          oldnv = c;
        }
        checkspeed = !checkspeed;
        if (isslow) {
          while (c > 1) {
            int ngroupsof5;
            ngroupsof5 = c / 5;
            *nlast = c - ngroupsof5 * 5;
            c = ngroupsof5;
            for (int k{0}; k < ngroupsof5; k++) {
              ipiv = (ia + k * 5) + 1;
              ipiv = thirdOfFive(v, ipiv, ipiv + 4) - 1;
              ilast = ia + k;
              vref = v[ilast];
              v[ilast] = v[ipiv];
              v[ipiv] = vref;
            }
            if (*nlast > 0) {
              ipiv = (ia + ngroupsof5 * 5) + 1;
              ipiv = thirdOfFive(v, ipiv, (ipiv + *nlast) - 1) - 1;
              ilast = ia + ngroupsof5;
              vref = v[ilast];
              v[ilast] = v[ipiv];
              v[ipiv] = vref;
              c = ngroupsof5 + 1;
            }
          }
        } else if (c >= 3) {
          ipiv = ia + static_cast<int>(static_cast<unsigned int>(c - 1) >> 1);
          if (v[ia] < v[ipiv]) {
            if (!(v[ipiv] < v[ib])) {
              if (v[ia] < v[ib]) {
                ipiv = ib;
              } else {
                ipiv = ia;
              }
            }
          } else if (v[ia] < v[ib]) {
            ipiv = ia;
          } else if (v[ipiv] < v[ib]) {
            ipiv = ib;
          }
          if (ipiv + 1 > ia + 1) {
            vref = v[ia];
            v[ia] = v[ipiv];
            v[ipiv] = vref;
          }
        }
        ipiv = ia + 1;
        *nfirst = ia + 1;
        ilast = ib;
      }
    }
    *vn = v[ilast];
    *nlast = ilast + 1;
  }
}

//
// Arguments    : ::coder::array<double, 2U> &x
// Return Type  : void
//
static void sort(::coder::array<double, 2U> &x)
{
  array<double, 1U> xwork;
  array<int, 2U> idx;
  array<int, 1U> iwork;
  int i;
  int ib;
  idx.set_size(1, x.size(1));
  ib = x.size(1);
  for (i = 0; i < ib; i++) {
    idx[i] = 0;
  }
  if (x.size(1) != 0) {
    double x4[4];
    int idx4[4];
    int bLen;
    int i2;
    int i3;
    int i4;
    int idx_tmp;
    int n;
    int nNonNaN;
    int quartetOffset;
    n = x.size(1);
    x4[0] = 0.0;
    idx4[0] = 0;
    x4[1] = 0.0;
    idx4[1] = 0;
    x4[2] = 0.0;
    idx4[2] = 0;
    x4[3] = 0.0;
    idx4[3] = 0;
    ib = x.size(1);
    iwork.set_size(ib);
    for (i = 0; i < ib; i++) {
      iwork[i] = 0;
    }
    ib = x.size(1);
    xwork.set_size(ib);
    for (i = 0; i < ib; i++) {
      xwork[i] = 0.0;
    }
    bLen = 0;
    ib = 0;
    for (int k{0}; k < n; k++) {
      if (std::isnan(x[k])) {
        idx_tmp = (n - bLen) - 1;
        idx[idx_tmp] = k + 1;
        xwork[idx_tmp] = x[k];
        bLen++;
      } else {
        ib++;
        idx4[ib - 1] = k + 1;
        x4[ib - 1] = x[k];
        if (ib == 4) {
          double d;
          double d1;
          signed char b_i2;
          signed char b_i3;
          signed char b_i4;
          signed char i1;
          quartetOffset = k - bLen;
          if (x4[0] <= x4[1]) {
            ib = 1;
            i2 = 2;
          } else {
            ib = 2;
            i2 = 1;
          }
          if (x4[2] <= x4[3]) {
            i3 = 3;
            i4 = 4;
          } else {
            i3 = 4;
            i4 = 3;
          }
          d = x4[ib - 1];
          d1 = x4[i3 - 1];
          if (d <= d1) {
            d = x4[i2 - 1];
            if (d <= d1) {
              i1 = static_cast<signed char>(ib);
              b_i2 = static_cast<signed char>(i2);
              b_i3 = static_cast<signed char>(i3);
              b_i4 = static_cast<signed char>(i4);
            } else if (d <= x4[i4 - 1]) {
              i1 = static_cast<signed char>(ib);
              b_i2 = static_cast<signed char>(i3);
              b_i3 = static_cast<signed char>(i2);
              b_i4 = static_cast<signed char>(i4);
            } else {
              i1 = static_cast<signed char>(ib);
              b_i2 = static_cast<signed char>(i3);
              b_i3 = static_cast<signed char>(i4);
              b_i4 = static_cast<signed char>(i2);
            }
          } else {
            d1 = x4[i4 - 1];
            if (d <= d1) {
              if (x4[i2 - 1] <= d1) {
                i1 = static_cast<signed char>(i3);
                b_i2 = static_cast<signed char>(ib);
                b_i3 = static_cast<signed char>(i2);
                b_i4 = static_cast<signed char>(i4);
              } else {
                i1 = static_cast<signed char>(i3);
                b_i2 = static_cast<signed char>(ib);
                b_i3 = static_cast<signed char>(i4);
                b_i4 = static_cast<signed char>(i2);
              }
            } else {
              i1 = static_cast<signed char>(i3);
              b_i2 = static_cast<signed char>(i4);
              b_i3 = static_cast<signed char>(ib);
              b_i4 = static_cast<signed char>(i2);
            }
          }
          idx[quartetOffset - 3] = idx4[i1 - 1];
          idx[quartetOffset - 2] = idx4[b_i2 - 1];
          idx[quartetOffset - 1] = idx4[b_i3 - 1];
          idx[quartetOffset] = idx4[b_i4 - 1];
          x[quartetOffset - 3] = x4[i1 - 1];
          x[quartetOffset - 2] = x4[b_i2 - 1];
          x[quartetOffset - 1] = x4[b_i3 - 1];
          x[quartetOffset] = x4[b_i4 - 1];
          ib = 0;
        }
      }
    }
    i3 = x.size(1) - bLen;
    if (ib > 0) {
      signed char perm[4];
      perm[1] = 0;
      perm[2] = 0;
      perm[3] = 0;
      if (ib == 1) {
        perm[0] = 1;
      } else if (ib == 2) {
        if (x4[0] <= x4[1]) {
          perm[0] = 1;
          perm[1] = 2;
        } else {
          perm[0] = 2;
          perm[1] = 1;
        }
      } else if (x4[0] <= x4[1]) {
        if (x4[1] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }
      i = static_cast<unsigned char>(ib);
      for (int k{0}; k < i; k++) {
        idx_tmp = perm[k] - 1;
        quartetOffset = (i3 - ib) + k;
        idx[quartetOffset] = idx4[idx_tmp];
        x[quartetOffset] = x4[idx_tmp];
      }
    }
    ib = bLen >> 1;
    for (int k{0}; k < ib; k++) {
      quartetOffset = i3 + k;
      i2 = idx[quartetOffset];
      idx_tmp = (n - k) - 1;
      idx[quartetOffset] = idx[idx_tmp];
      idx[idx_tmp] = i2;
      x[quartetOffset] = xwork[idx_tmp];
      x[idx_tmp] = xwork[quartetOffset];
    }
    if ((bLen & 1) != 0) {
      i = i3 + ib;
      x[i] = xwork[i];
    }
    nNonNaN = x.size(1) - bLen;
    ib = 2;
    if (nNonNaN > 1) {
      if (x.size(1) >= 256) {
        int nBlocks;
        nBlocks = nNonNaN >> 8;
        if (nBlocks > 0) {
          for (int b{0}; b < nBlocks; b++) {
            double b_xwork[256];
            int b_iwork[256];
            i4 = (b << 8) - 1;
            for (int b_b{0}; b_b < 6; b_b++) {
              bLen = 1 << (b_b + 2);
              n = bLen << 1;
              i = 256 >> (b_b + 3);
              for (int k{0}; k < i; k++) {
                i2 = (i4 + k * n) + 1;
                for (quartetOffset = 0; quartetOffset < n; quartetOffset++) {
                  ib = i2 + quartetOffset;
                  b_iwork[quartetOffset] = idx[ib];
                  b_xwork[quartetOffset] = x[ib];
                }
                i3 = 0;
                quartetOffset = bLen;
                ib = i2 - 1;
                int exitg1;
                do {
                  exitg1 = 0;
                  ib++;
                  if (b_xwork[i3] <= b_xwork[quartetOffset]) {
                    idx[ib] = b_iwork[i3];
                    x[ib] = b_xwork[i3];
                    if (i3 + 1 < bLen) {
                      i3++;
                    } else {
                      exitg1 = 1;
                    }
                  } else {
                    idx[ib] = b_iwork[quartetOffset];
                    x[ib] = b_xwork[quartetOffset];
                    if (quartetOffset + 1 < n) {
                      quartetOffset++;
                    } else {
                      ib -= i3;
                      for (quartetOffset = i3 + 1; quartetOffset <= bLen;
                           quartetOffset++) {
                        idx_tmp = ib + quartetOffset;
                        idx[idx_tmp] = b_iwork[quartetOffset - 1];
                        x[idx_tmp] = b_xwork[quartetOffset - 1];
                      }
                      exitg1 = 1;
                    }
                  }
                } while (exitg1 == 0);
              }
            }
          }
          ib = nBlocks << 8;
          quartetOffset = nNonNaN - ib;
          if (quartetOffset > 0) {
            merge_block(idx, x, ib, quartetOffset, 2, iwork, xwork);
          }
          ib = 8;
        }
      }
      merge_block(idx, x, 0, nNonNaN, ib, iwork, xwork);
    }
  }
}

//
// Arguments    : ::coder::array<double, 1U> &x
// Return Type  : void
//
static void sort(::coder::array<double, 1U> &x)
{
  array<double, 1U> b_xwork;
  array<double, 1U> vwork;
  array<double, 1U> xwork;
  array<int, 1U> b_iwork;
  array<int, 1U> iidx;
  array<int, 1U> iwork;
  int dim;
  int i;
  int vlen;
  int vstride;
  dim = 0;
  if (x.size(0) != 1) {
    dim = -1;
  }
  if (dim + 2 <= 1) {
    i = x.size(0);
  } else {
    i = 1;
  }
  vlen = i - 1;
  vwork.set_size(i);
  vstride = 1;
  for (int k{0}; k <= dim; k++) {
    vstride *= x.size(0);
  }
  for (int j{0}; j < vstride; j++) {
    for (int k{0}; k <= vlen; k++) {
      vwork[k] = x[j + k * vstride];
    }
    iidx.set_size(vwork.size(0));
    dim = vwork.size(0);
    for (i = 0; i < dim; i++) {
      iidx[i] = 0;
    }
    if (vwork.size(0) != 0) {
      double x4[4];
      int idx4[4];
      int bLen2;
      int i1;
      int i2;
      int i3;
      int i4;
      int iidx_tmp;
      int n;
      int nNonNaN;
      n = vwork.size(0);
      x4[0] = 0.0;
      idx4[0] = 0;
      x4[1] = 0.0;
      idx4[1] = 0;
      x4[2] = 0.0;
      idx4[2] = 0;
      x4[3] = 0.0;
      idx4[3] = 0;
      iwork.set_size(vwork.size(0));
      dim = vwork.size(0);
      for (i = 0; i < dim; i++) {
        iwork[i] = 0;
      }
      xwork.set_size(vwork.size(0));
      dim = vwork.size(0);
      for (i = 0; i < dim; i++) {
        xwork[i] = 0.0;
      }
      bLen2 = 0;
      dim = 0;
      for (int k{0}; k < n; k++) {
        if (std::isnan(vwork[k])) {
          iidx_tmp = (n - bLen2) - 1;
          iidx[iidx_tmp] = k + 1;
          xwork[iidx_tmp] = vwork[k];
          bLen2++;
        } else {
          dim++;
          idx4[dim - 1] = k + 1;
          x4[dim - 1] = vwork[k];
          if (dim == 4) {
            double d;
            double d1;
            signed char b_i1;
            signed char b_i2;
            signed char b_i3;
            signed char b_i4;
            dim = k - bLen2;
            if (x4[0] <= x4[1]) {
              i1 = 1;
              i2 = 2;
            } else {
              i1 = 2;
              i2 = 1;
            }
            if (x4[2] <= x4[3]) {
              i3 = 3;
              i4 = 4;
            } else {
              i3 = 4;
              i4 = 3;
            }
            d = x4[i1 - 1];
            d1 = x4[i3 - 1];
            if (d <= d1) {
              d = x4[i2 - 1];
              if (d <= d1) {
                b_i1 = static_cast<signed char>(i1);
                b_i2 = static_cast<signed char>(i2);
                b_i3 = static_cast<signed char>(i3);
                b_i4 = static_cast<signed char>(i4);
              } else if (d <= x4[i4 - 1]) {
                b_i1 = static_cast<signed char>(i1);
                b_i2 = static_cast<signed char>(i3);
                b_i3 = static_cast<signed char>(i2);
                b_i4 = static_cast<signed char>(i4);
              } else {
                b_i1 = static_cast<signed char>(i1);
                b_i2 = static_cast<signed char>(i3);
                b_i3 = static_cast<signed char>(i4);
                b_i4 = static_cast<signed char>(i2);
              }
            } else {
              d1 = x4[i4 - 1];
              if (d <= d1) {
                if (x4[i2 - 1] <= d1) {
                  b_i1 = static_cast<signed char>(i3);
                  b_i2 = static_cast<signed char>(i1);
                  b_i3 = static_cast<signed char>(i2);
                  b_i4 = static_cast<signed char>(i4);
                } else {
                  b_i1 = static_cast<signed char>(i3);
                  b_i2 = static_cast<signed char>(i1);
                  b_i3 = static_cast<signed char>(i4);
                  b_i4 = static_cast<signed char>(i2);
                }
              } else {
                b_i1 = static_cast<signed char>(i3);
                b_i2 = static_cast<signed char>(i4);
                b_i3 = static_cast<signed char>(i1);
                b_i4 = static_cast<signed char>(i2);
              }
            }
            iidx[dim - 3] = idx4[b_i1 - 1];
            iidx[dim - 2] = idx4[b_i2 - 1];
            iidx[dim - 1] = idx4[b_i3 - 1];
            iidx[dim] = idx4[b_i4 - 1];
            vwork[dim - 3] = x4[b_i1 - 1];
            vwork[dim - 2] = x4[b_i2 - 1];
            vwork[dim - 1] = x4[b_i3 - 1];
            vwork[dim] = x4[b_i4 - 1];
            dim = 0;
          }
        }
      }
      i3 = vwork.size(0) - bLen2;
      if (dim > 0) {
        signed char perm[4];
        perm[1] = 0;
        perm[2] = 0;
        perm[3] = 0;
        if (dim == 1) {
          perm[0] = 1;
        } else if (dim == 2) {
          if (x4[0] <= x4[1]) {
            perm[0] = 1;
            perm[1] = 2;
          } else {
            perm[0] = 2;
            perm[1] = 1;
          }
        } else if (x4[0] <= x4[1]) {
          if (x4[1] <= x4[2]) {
            perm[0] = 1;
            perm[1] = 2;
            perm[2] = 3;
          } else if (x4[0] <= x4[2]) {
            perm[0] = 1;
            perm[1] = 3;
            perm[2] = 2;
          } else {
            perm[0] = 3;
            perm[1] = 1;
            perm[2] = 2;
          }
        } else if (x4[0] <= x4[2]) {
          perm[0] = 2;
          perm[1] = 1;
          perm[2] = 3;
        } else if (x4[1] <= x4[2]) {
          perm[0] = 2;
          perm[1] = 3;
          perm[2] = 1;
        } else {
          perm[0] = 3;
          perm[1] = 2;
          perm[2] = 1;
        }
        i = static_cast<unsigned char>(dim);
        for (int k{0}; k < i; k++) {
          iidx_tmp = perm[k] - 1;
          i1 = (i3 - dim) + k;
          iidx[i1] = idx4[iidx_tmp];
          vwork[i1] = x4[iidx_tmp];
        }
      }
      dim = bLen2 >> 1;
      for (int k{0}; k < dim; k++) {
        i1 = i3 + k;
        i2 = iidx[i1];
        iidx_tmp = (n - k) - 1;
        iidx[i1] = iidx[iidx_tmp];
        iidx[iidx_tmp] = i2;
        vwork[i1] = xwork[iidx_tmp];
        vwork[iidx_tmp] = xwork[i1];
      }
      if ((bLen2 & 1) != 0) {
        dim += i3;
        vwork[dim] = xwork[dim];
      }
      nNonNaN = vwork.size(0) - bLen2;
      i1 = 2;
      if (nNonNaN > 1) {
        if (vwork.size(0) >= 256) {
          int nBlocks;
          nBlocks = nNonNaN >> 8;
          if (nBlocks > 0) {
            for (int b{0}; b < nBlocks; b++) {
              double c_xwork[256];
              int c_iwork[256];
              i4 = (b << 8) - 1;
              for (int b_b{0}; b_b < 6; b_b++) {
                n = 1 << (b_b + 2);
                bLen2 = n << 1;
                i = 256 >> (b_b + 3);
                for (int k{0}; k < i; k++) {
                  i2 = (i4 + k * bLen2) + 1;
                  for (i1 = 0; i1 < bLen2; i1++) {
                    dim = i2 + i1;
                    c_iwork[i1] = iidx[dim];
                    c_xwork[i1] = vwork[dim];
                  }
                  i3 = 0;
                  i1 = n;
                  dim = i2 - 1;
                  int exitg1;
                  do {
                    exitg1 = 0;
                    dim++;
                    if (c_xwork[i3] <= c_xwork[i1]) {
                      iidx[dim] = c_iwork[i3];
                      vwork[dim] = c_xwork[i3];
                      if (i3 + 1 < n) {
                        i3++;
                      } else {
                        exitg1 = 1;
                      }
                    } else {
                      iidx[dim] = c_iwork[i1];
                      vwork[dim] = c_xwork[i1];
                      if (i1 + 1 < bLen2) {
                        i1++;
                      } else {
                        dim -= i3;
                        for (i1 = i3 + 1; i1 <= n; i1++) {
                          iidx_tmp = dim + i1;
                          iidx[iidx_tmp] = c_iwork[i1 - 1];
                          vwork[iidx_tmp] = c_xwork[i1 - 1];
                        }
                        exitg1 = 1;
                      }
                    }
                  } while (exitg1 == 0);
                }
              }
            }
            dim = nBlocks << 8;
            i1 = nNonNaN - dim;
            if (i1 > 0) {
              merge_block(iidx, vwork, dim, i1, 2, iwork, xwork);
            }
            i1 = 8;
          }
        }
        dim = iwork.size(0);
        b_iwork.set_size(iwork.size(0));
        for (i = 0; i < dim; i++) {
          b_iwork[i] = iwork[i];
        }
        b_xwork.set_size(xwork.size(0));
        dim = xwork.size(0);
        for (i = 0; i < dim; i++) {
          b_xwork[i] = xwork[i];
        }
        merge_block(iidx, vwork, 0, nNonNaN, i1, b_iwork, b_xwork);
      }
    }
    for (int k{0}; k <= vlen; k++) {
      x[j + k * vstride] = vwork[k];
    }
  }
}

//
// Arguments    : const ::coder::array<double, 2U> &v
//                int ia
//                int ib
// Return Type  : int
//
static int thirdOfFive(const ::coder::array<double, 2U> &v, int ia, int ib)
{
  int im;
  if ((ia == ib) || (ia + 1 == ib)) {
    im = ia;
  } else if ((ia + 2 == ib) || (ia + 3 == ib)) {
    double v4;
    v4 = v[ia - 1];
    if (v4 < v[ia]) {
      if (v[ia] < v[ia + 1]) {
        im = ia + 1;
      } else if (v[ia - 1] < v[ia + 1]) {
        im = ia + 2;
      } else {
        im = ia;
      }
    } else if (v4 < v[ia + 1]) {
      im = ia;
    } else if (v[ia] < v[ia + 1]) {
      im = ia + 2;
    } else {
      im = ia + 1;
    }
  } else {
    double v4;
    double v5;
    int j2;
    int j3;
    int j4;
    int j5;
    v4 = v[ia - 1];
    if (v4 < v[ia]) {
      v5 = v[ia + 1];
      if (v[ia] < v5) {
        im = ia;
        j2 = ia;
        j3 = ia + 2;
      } else if (v4 < v5) {
        im = ia;
        j2 = ia + 1;
        j3 = ia + 1;
      } else {
        im = ia + 2;
        j2 = ia - 1;
        j3 = ia + 1;
      }
    } else {
      v5 = v[ia + 1];
      if (v4 < v5) {
        im = ia + 1;
        j2 = ia - 1;
        j3 = ia + 2;
      } else if (v[ia] < v5) {
        im = ia + 1;
        j2 = ia + 1;
        j3 = ia;
      } else {
        im = ia + 2;
        j2 = ia;
        j3 = ia;
      }
    }
    j4 = ia;
    j5 = ia + 1;
    v4 = v[ia + 2];
    v5 = v[ia + 3];
    if (v5 < v4) {
      j4 = ia + 1;
      j5 = ia;
      v5 = v4;
      v4 = v[ia + 3];
    }
    if (!(v5 < v[im - 1])) {
      if (v5 < v[j2]) {
        im = j5 + 3;
      } else if (v4 < v[j2]) {
        im = j2 + 1;
      } else if (v4 < v[j3 - 1]) {
        im = j4 + 3;
      } else {
        im = j3;
      }
    }
  }
  return im;
}

//
// Arguments    : const double varargin_1[55]
//                const ::coder::array<double, 2U> &varargin_3
//                ::coder::array<double, 2U> &Vq
// Return Type  : void
//
} // namespace internal
static void interp1(const double varargin_1[55],
                    const ::coder::array<double, 2U> &varargin_3,
                    ::coder::array<double, 2U> &Vq)
{
  double x[55];
  double y[55];
  int loop_ub;
  boolean_T b;
  boolean_T b1;
  for (int i{0}; i < 55; i++) {
    x[i] = varargin_1[i];
    y[i] = 4.7222222222222223 * static_cast<double>(i) + 1.0;
  }
  Vq.set_size(varargin_3.size(0), varargin_3.size(1));
  loop_ub = varargin_3.size(0) * varargin_3.size(1);
  for (int i{0}; i < loop_ub; i++) {
    Vq[i] = rtNaN;
  }
  b = (varargin_3.size(0) == 0);
  b1 = (varargin_3.size(1) == 0);
  if ((!b) && (!b1)) {
    loop_ub = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (loop_ub < 55) {
        if (std::isnan(varargin_1[loop_ub])) {
          exitg1 = 1;
        } else {
          loop_ub++;
        }
      } else {
        if (varargin_1[1] < varargin_1[0]) {
          for (loop_ub = 0; loop_ub < 27; loop_ub++) {
            double xtmp;
            xtmp = x[loop_ub];
            x[loop_ub] = x[54 - loop_ub];
            x[54 - loop_ub] = xtmp;
            xtmp = y[loop_ub];
            y[loop_ub] = y[54 - loop_ub];
            y[54 - loop_ub] = xtmp;
          }
        }
        interp1Linear(y, varargin_3, Vq, x);
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
}

//
// Arguments    : const double y[55]
//                const ::coder::array<double, 2U> &xi
//                ::coder::array<double, 2U> &yi
//                const double varargin_1[55]
// Return Type  : void
//
static void interp1Linear(const double y[55],
                          const ::coder::array<double, 2U> &xi,
                          ::coder::array<double, 2U> &yi,
                          const double varargin_1[55])
{
  double d;
  double maxx;
  double minx;
  double r;
  int high_i;
  int low_i;
  int low_ip1;
  int mid_i;
  int ub_loop;
  minx = varargin_1[0];
  maxx = varargin_1[54];
  ub_loop = xi.size(0) * xi.size(1) - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
    low_i, low_ip1, high_i, r, mid_i, d)

  for (int k = 0; k <= ub_loop; k++) {
    if (std::isnan(xi[k])) {
      yi[k] = rtNaN;
    } else if ((!(xi[k] > maxx)) && (!(xi[k] < minx))) {
      low_i = 1;
      low_ip1 = 2;
      high_i = 55;
      while (high_i > low_ip1) {
        mid_i = (low_i + high_i) >> 1;
        if (xi[k] >= varargin_1[mid_i - 1]) {
          low_i = mid_i;
          low_ip1 = mid_i + 1;
        } else {
          high_i = mid_i;
        }
      }
      r = varargin_1[low_i - 1];
      r = (xi[k] - r) / (varargin_1[low_i] - r);
      if (r == 0.0) {
        yi[k] = y[low_i - 1];
      } else if (r == 1.0) {
        yi[k] = y[low_i];
      } else {
        d = y[low_i - 1];
        if (d == y[low_i]) {
          yi[k] = d;
        } else {
          yi[k] = (1.0 - r) * d + r * y[low_i];
        }
      }
    }
  }
}

//
// Arguments    : const ::coder::array<double, 1U> &x
// Return Type  : double
//
static double mean(const ::coder::array<double, 1U> &x)
{
  double y;
  if (x.size(0) == 0) {
    y = 0.0;
  } else {
    int firstBlockLength;
    int lastBlockLength;
    int nblocks;
    if (x.size(0) <= 1024) {
      firstBlockLength = x.size(0);
      lastBlockLength = 0;
      nblocks = 1;
    } else {
      firstBlockLength = 1024;
      nblocks = static_cast<int>(static_cast<unsigned int>(x.size(0)) >> 10);
      lastBlockLength = x.size(0) - (nblocks << 10);
      if (lastBlockLength > 0) {
        nblocks++;
      } else {
        lastBlockLength = 1024;
      }
    }
    y = x[0];
    for (int k{2}; k <= firstBlockLength; k++) {
      y += x[k - 1];
    }
    for (int ib{2}; ib <= nblocks; ib++) {
      double bsum;
      int hi;
      firstBlockLength = (ib - 1) << 10;
      bsum = x[firstBlockLength];
      if (ib == nblocks) {
        hi = lastBlockLength;
      } else {
        hi = 1024;
      }
      for (int k{2}; k <= hi; k++) {
        bsum += x[(firstBlockLength + k) - 1];
      }
      y += bsum;
    }
  }
  y /= static_cast<double>(x.size(0));
  return y;
}

//
// Arguments    : const ::coder::array<double, 2U> &x
// Return Type  : double
//
static double median(const ::coder::array<double, 2U> &x)
{
  array<double, 2U> a__4;
  double b;
  double y;
  int a__6;
  int k;
  int vlen;
  vlen = x.size(1);
  if (x.size(1) == 0) {
    y = rtNaN;
  } else {
    k = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (k <= vlen - 1) {
        if (std::isnan(x[k])) {
          y = rtNaN;
          exitg1 = 1;
        } else {
          k++;
        }
      } else {
        if (vlen <= 4) {
          if (vlen == 0) {
            y = rtNaN;
          } else if (vlen == 1) {
            y = x[0];
          } else if (vlen == 2) {
            if (((x[0] < 0.0) != (x[1] < 0.0)) || std::isinf(x[0])) {
              y = (x[0] + x[1]) / 2.0;
            } else {
              y = x[0] + (x[1] - x[0]) / 2.0;
            }
          } else if (vlen == 3) {
            if (x[0] < x[1]) {
              if (x[1] < x[2]) {
                a__6 = 1;
              } else if (x[0] < x[2]) {
                a__6 = 2;
              } else {
                a__6 = 0;
              }
            } else if (x[0] < x[2]) {
              a__6 = 0;
            } else if (x[1] < x[2]) {
              a__6 = 2;
            } else {
              a__6 = 1;
            }
            y = x[a__6];
          } else {
            if (x[0] < x[1]) {
              if (x[1] < x[2]) {
                k = 0;
                a__6 = 1;
                vlen = 2;
              } else if (x[0] < x[2]) {
                k = 0;
                a__6 = 2;
                vlen = 1;
              } else {
                k = 2;
                a__6 = 0;
                vlen = 1;
              }
            } else if (x[0] < x[2]) {
              k = 1;
              a__6 = 0;
              vlen = 2;
            } else if (x[1] < x[2]) {
              k = 1;
              a__6 = 2;
              vlen = 0;
            } else {
              k = 2;
              a__6 = 1;
              vlen = 0;
            }
            if (x[k] < x[3]) {
              if (x[3] < x[vlen]) {
                if (((x[a__6] < 0.0) != (x[3] < 0.0)) || std::isinf(x[a__6])) {
                  y = (x[a__6] + x[3]) / 2.0;
                } else {
                  y = x[a__6] + (x[3] - x[a__6]) / 2.0;
                }
              } else if (((x[a__6] < 0.0) != (x[vlen] < 0.0)) ||
                         std::isinf(x[a__6])) {
                y = (x[a__6] + x[vlen]) / 2.0;
              } else {
                y = x[a__6] + (x[vlen] - x[a__6]) / 2.0;
              }
            } else if (((x[k] < 0.0) != (x[a__6] < 0.0)) || std::isinf(x[k])) {
              y = (x[k] + x[a__6]) / 2.0;
            } else {
              y = x[k] + (x[a__6] - x[k]) / 2.0;
            }
          }
        } else {
          int midm1;
          midm1 = vlen >> 1;
          if ((vlen & 1) == 0) {
            a__4.set_size(1, x.size(1));
            k = x.size(1);
            for (a__6 = 0; a__6 < k; a__6++) {
              a__4[a__6] = x[a__6];
            }
            internal::quickselect(a__4, midm1 + 1, vlen, &y, &k, &a__6);
            if (midm1 < k) {
              internal::quickselect(a__4, midm1, a__6 - 1, &b, &k, &vlen);
              if (((y < 0.0) != (b < 0.0)) || std::isinf(y)) {
                y = (y + b) / 2.0;
              } else {
                y += (b - y) / 2.0;
              }
            }
          } else {
            a__4.set_size(1, x.size(1));
            k = x.size(1);
            for (a__6 = 0; a__6 < k; a__6++) {
              a__4[a__6] = x[a__6];
            }
            internal::quickselect(a__4, midm1 + 1, vlen, &y, &k, &a__6);
          }
        }
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
  return y;
}

//
// Arguments    : const ::coder::array<double, 2U> &a_tmp
//                const double pad[2]
//                ::coder::array<double, 2U> &a
// Return Type  : void
//
static void padImage(const ::coder::array<double, 2U> &a_tmp,
                     const double pad[2], ::coder::array<double, 2U> &a)
{
  array<int, 2U> idxA;
  array<unsigned int, 2U> idxDir;
  array<unsigned int, 2U> y;
  if ((a_tmp.size(0) == 0) || (a_tmp.size(1) == 0)) {
    double sizeA_idx_0;
    double sizeA_idx_1;
    int loop_ub;
    sizeA_idx_0 = static_cast<double>(a_tmp.size(0)) + 2.0 * pad[0];
    sizeA_idx_1 = static_cast<double>(a_tmp.size(1)) + 2.0 * pad[1];
    a.set_size(static_cast<int>(sizeA_idx_0), static_cast<int>(sizeA_idx_1));
    loop_ub = static_cast<int>(sizeA_idx_0) * static_cast<int>(sizeA_idx_1);
    for (int i{0}; i < loop_ub; i++) {
      a[i] = 0.0;
    }
  } else {
    int i;
    int loop_ub;
    unsigned int u;
    if (static_cast<unsigned int>(a_tmp.size(0)) + 8U <
        static_cast<unsigned int>(a_tmp.size(1)) + 8U) {
      u = static_cast<unsigned int>(a_tmp.size(1)) + 8U;
    } else {
      u = static_cast<unsigned int>(a_tmp.size(0)) + 8U;
    }
    idxA.set_size(static_cast<int>(u), 2);
    y.set_size(1, a_tmp.size(0));
    loop_ub = a_tmp.size(0) - 1;
    for (i = 0; i <= loop_ub; i++) {
      y[i] = static_cast<unsigned int>(i) + 1U;
    }
    idxDir.set_size(1, y.size(1) + 8);
    idxDir[0] = 1U;
    idxDir[1] = 1U;
    idxDir[2] = 1U;
    idxDir[3] = 1U;
    loop_ub = y.size(1);
    for (i = 0; i < loop_ub; i++) {
      idxDir[i + 4] = y[i];
    }
    idxDir[y.size(1) + 4] = static_cast<unsigned int>(a_tmp.size(0));
    idxDir[y.size(1) + 5] = static_cast<unsigned int>(a_tmp.size(0));
    idxDir[y.size(1) + 6] = static_cast<unsigned int>(a_tmp.size(0));
    idxDir[y.size(1) + 7] = static_cast<unsigned int>(a_tmp.size(0));
    loop_ub = idxDir.size(1);
    for (i = 0; i < loop_ub; i++) {
      idxA[i] = static_cast<int>(idxDir[i]);
    }
    y.set_size(1, a_tmp.size(1));
    loop_ub = a_tmp.size(1) - 1;
    for (i = 0; i <= loop_ub; i++) {
      y[i] = static_cast<unsigned int>(i) + 1U;
    }
    idxDir.set_size(1, y.size(1) + 8);
    idxDir[0] = 1U;
    idxDir[1] = 1U;
    idxDir[2] = 1U;
    idxDir[3] = 1U;
    loop_ub = y.size(1);
    for (i = 0; i < loop_ub; i++) {
      idxDir[i + 4] = y[i];
    }
    idxDir[y.size(1) + 4] = static_cast<unsigned int>(a_tmp.size(1));
    idxDir[y.size(1) + 5] = static_cast<unsigned int>(a_tmp.size(1));
    idxDir[y.size(1) + 6] = static_cast<unsigned int>(a_tmp.size(1));
    idxDir[y.size(1) + 7] = static_cast<unsigned int>(a_tmp.size(1));
    loop_ub = idxDir.size(1);
    for (i = 0; i < loop_ub; i++) {
      idxA[i + idxA.size(0)] = static_cast<int>(idxDir[i]);
    }
    i = static_cast<int>(static_cast<double>(a_tmp.size(1)) + 2.0 * pad[1]);
    a.set_size(
        static_cast<int>(static_cast<double>(a_tmp.size(0)) + 2.0 * pad[0]),
        static_cast<int>(static_cast<double>(a_tmp.size(1)) + 2.0 * pad[1]));
    for (int j{0}; j < i; j++) {
      loop_ub = a.size(0);
      for (int b_i{0}; b_i < loop_ub; b_i++) {
        a[b_i + a.size(0) * j] =
            a_tmp[(idxA[b_i] + a_tmp.size(0) * (idxA[j + idxA.size(0)] - 1)) -
                  1];
      }
    }
  }
}

//
// Arguments    : const double A[81]
//                double U[81]
//                double S[81]
//                double V[81]
// Return Type  : void
//
static void svd(const double A[81], double U[81], double S[81], double V[81])
{
  double s[9];
  boolean_T p;
  p = true;
  for (int i{0}; i < 81; i++) {
    if (p) {
      double d;
      d = A[i];
      if (std::isinf(d) || std::isnan(d)) {
        p = false;
      }
    } else {
      p = false;
    }
  }
  if (p) {
    internal::b_svd(A, U, s, V);
  } else {
    for (int i{0}; i < 81; i++) {
      U[i] = rtNaN;
    }
    for (int i{0}; i < 9; i++) {
      s[i] = rtNaN;
    }
    for (int i{0}; i < 81; i++) {
      V[i] = rtNaN;
    }
  }
  std::memset(&S[0], 0, 81U * sizeof(double));
  for (int i{0}; i < 9; i++) {
    S[i + 9 * i] = s[i];
  }
}

//
// Arguments    : double u0
//                double u1
// Return Type  : double
//
} // namespace coder
static double rt_powd_snf(double u0, double u1)
{
  double y;
  if (std::isnan(u0) || std::isnan(u1)) {
    y = rtNaN;
  } else {
    double d;
    double d1;
    d = std::abs(u0);
    d1 = std::abs(u1);
    if (std::isinf(u1)) {
      if (d == 1.0) {
        y = 1.0;
      } else if (d > 1.0) {
        if (u1 > 0.0) {
          y = rtInf;
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = rtInf;
      }
    } else if (d1 == 0.0) {
      y = 1.0;
    } else if (d1 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = rtNaN;
    } else {
      y = std::pow(u0, u1);
    }
  }
  return y;
}

//
// ---------------------------------------
//  The output is the sensitivity of HVS measured as just noticeable
//  difference in the ambient intensity defined by the input parameter.
//
//  intensity: real luminance in log10 domain
//  threshold: in log10 domain, delta(lum)=10.^(threshold)
//
// Arguments    : double intensity
// Return Type  : double
//
static double tvi(double intensity)
{
  double d;
  double tmp_data;
  int ii_size_idx_0;
  int ii_size_idx_1;
  int loop_ub;
  if (intensity < -3.94) {
    ii_size_idx_0 = 1;
    ii_size_idx_1 = 1;
  } else {
    ii_size_idx_0 = 0;
    ii_size_idx_1 = 0;
  }
  d = 0.0;
  loop_ub = ii_size_idx_0 * ii_size_idx_1;
  for (int i{0}; i < loop_ub; i++) {
    d = -2.86;
  }
  if ((intensity >= -3.94) && (intensity < -1.44)) {
    ii_size_idx_0 = 1;
    ii_size_idx_1 = 1;
  } else {
    ii_size_idx_0 = 0;
    ii_size_idx_1 = 0;
  }
  loop_ub = ii_size_idx_0 * ii_size_idx_1;
  for (int i{0}; i < loop_ub; i++) {
    tmp_data = rt_powd_snf(0.405 * intensity + 1.6, 2.18);
  }
  loop_ub = ii_size_idx_0 * ii_size_idx_1;
  for (int i{0}; i < loop_ub; i++) {
    d = tmp_data - 2.86;
  }
  if ((intensity >= -1.44) && (intensity < -0.0184)) {
    ii_size_idx_0 = 1;
    ii_size_idx_1 = 1;
  } else {
    ii_size_idx_0 = 0;
    ii_size_idx_1 = 0;
  }
  loop_ub = ii_size_idx_0 * ii_size_idx_1;
  for (int i{0}; i < loop_ub; i++) {
    d = intensity - 0.395;
  }
  if ((intensity >= -0.0184) && (intensity < 1.9)) {
    ii_size_idx_0 = 1;
    ii_size_idx_1 = 1;
  } else {
    ii_size_idx_0 = 0;
    ii_size_idx_1 = 0;
  }
  loop_ub = ii_size_idx_0 * ii_size_idx_1;
  for (int i{0}; i < loop_ub; i++) {
    tmp_data = rt_powd_snf(0.249 * intensity + 0.65, 2.7);
  }
  loop_ub = ii_size_idx_0 * ii_size_idx_1;
  for (int i{0}; i < loop_ub; i++) {
    d = tmp_data - 0.72;
  }
  if (intensity >= 1.9) {
    ii_size_idx_0 = 1;
    ii_size_idx_1 = 1;
  } else {
    ii_size_idx_0 = 0;
    ii_size_idx_1 = 0;
  }
  loop_ub = ii_size_idx_0 * ii_size_idx_1;
  for (int i{0}; i < loop_ub; i++) {
    d = intensity - 1.255;
  }
  return d - 0.95;
}

//
// set parameters
//
// Arguments    : coder::array<double, 3U> &hdrImg
//                coder::array<double, 3U> &ldrImg
// Return Type  : void
//
void DCA_TMO(coder::array<double, 3U> &hdrImg, coder::array<double, 3U> &ldrImg)
{
  coder::array<double, 3U> c_hdrImg;
  coder::array<double, 2U> b_lum;
  coder::array<double, 2U> hdrLum;
  coder::array<double, 2U> hdrPQ;
  coder::array<double, 2U> labels_DoG;
  coder::array<double, 2U> lum;
  coder::array<double, 2U> s_data;
  coder::array<double, 2U> varargin_1;
  coder::array<double, 2U> y;
  coder::array<double, 1U> b_hdrImg;
  coder::array<double, 1U> matrix;
  coder::array<int, 1U> r;
  coder::array<int, 1U> r1;
  coder::array<int, 1U> r2;
  coder::array<int, 1U> r3;
  coder::array<int, 1U> r4;
  coder::array<int, 1U> r5;
  coder::array<boolean_T, 2U> ind;
  double a__1[55];
  double e2;
  double m;
  double minn;
  int edgesRes[3];
  int i;
  int k;
  int last;
  int loop_ub;
  int n;
  int nx;
  unsigned int varargin_1_idx_1;
  if (!isInitialized_DCA_TMO) {
    DCA_TMO_initialize();
  }
  //  pre-processing
  //  [N, M, C] = size(hdrImg);
  //
  //        ret = MaxQuart(matrix, percentile)
  //
  //        Input:
  //            -matrix: a matrix
  //            -percentile: a value in the range [0,1]
  //
  //        Output:
  //            -ret: the percentile of the input matrix
  //
  //      Copyright (C) 2011-2015  Francesco Banterle
  //
  //      This program is free software: you can redistribute it and/or modify
  //      it under the terms of the GNU General Public License as published by
  //      the Free Software Foundation, either version 3 of the License, or
  //      (at your option) any later version.
  //
  //      This program is distributed in the hope that it will be useful,
  //      but WITHOUT ANY WARRANTY; without even the implied warranty of
  //      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  //      GNU General Public License for more details.
  //
  //      You should have received a copy of the GNU General Public License
  //      along with this program.  If not, see <http://www.gnu.org/licenses/>.
  //
  matrix.set_size(hdrImg.size(0) * hdrImg.size(1) * 3);
  loop_ub = hdrImg.size(0) * hdrImg.size(1) * 3;
  for (i = 0; i < loop_ub; i++) {
    matrix[i] = hdrImg[i];
  }
  coder::internal::sort(matrix);
  i = static_cast<int>(std::round(
      static_cast<double>(hdrImg.size(0) * hdrImg.size(1) * 3) * 0.99));
  if (i < 1) {
    i = 1;
  }
  e2 = matrix[i - 1];
  //
  //        ret = MaxQuart(matrix, percentile)
  //
  //        Input:
  //            -matrix: a matrix
  //            -percentile: a value in the range [0,1]
  //
  //        Output:
  //            -ret: the percentile of the input matrix
  //
  //      Copyright (C) 2011-2015  Francesco Banterle
  //
  //      This program is free software: you can redistribute it and/or modify
  //      it under the terms of the GNU General Public License as published by
  //      the Free Software Foundation, either version 3 of the License, or
  //      (at your option) any later version.
  //
  //      This program is distributed in the hope that it will be useful,
  //      but WITHOUT ANY WARRANTY; without even the implied warranty of
  //      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  //      GNU General Public License for more details.
  //
  //      You should have received a copy of the GNU General Public License
  //      along with this program.  If not, see <http://www.gnu.org/licenses/>.
  //
  matrix.set_size(hdrImg.size(0) * hdrImg.size(1) * 3);
  loop_ub = hdrImg.size(0) * hdrImg.size(1) * 3;
  for (i = 0; i < loop_ub; i++) {
    matrix[i] = hdrImg[i];
  }
  coder::internal::sort(matrix);
  i = static_cast<int>(std::round(
      static_cast<double>(hdrImg.size(0) * hdrImg.size(1) * 3) * 0.01));
  if (i < 1) {
    i = 1;
  }
  minn = matrix[i - 1];
  last = hdrImg.size(0) * (hdrImg.size(1) * 3) - 1;
  nx = 0;
  for (int b_i{0}; b_i <= last; b_i++) {
    if (hdrImg[b_i] > e2) {
      nx++;
    }
  }
  r.set_size(nx);
  nx = 0;
  for (int b_i{0}; b_i <= last; b_i++) {
    if (hdrImg[b_i] > e2) {
      r[nx] = b_i + 1;
      nx++;
    }
  }
  loop_ub = r.size(0);
  for (i = 0; i < loop_ub; i++) {
    hdrImg[r[i] - 1] = e2;
  }
  last = hdrImg.size(0) * (hdrImg.size(1) * 3) - 1;
  nx = 0;
  for (int b_i{0}; b_i <= last; b_i++) {
    if (hdrImg[b_i] < minn) {
      nx++;
    }
  }
  r1.set_size(nx);
  nx = 0;
  for (int b_i{0}; b_i <= last; b_i++) {
    if (hdrImg[b_i] < minn) {
      r1[nx] = b_i + 1;
      nx++;
    }
  }
  loop_ub = r1.size(0);
  for (i = 0; i < loop_ub; i++) {
    hdrImg[r1[i] - 1] = minn;
  }
  //  tone map using clustering method
  hdrLum.set_size(hdrImg.size(0), hdrImg.size(1));
  loop_ub = hdrImg.size(1);
  for (i = 0; i < loop_ub; i++) {
    nx = hdrImg.size(0);
    for (k = 0; k < nx; k++) {
      hdrLum[k + hdrLum.size(0) * i] =
          (0.2126 * hdrImg[k + hdrImg.size(0) * i] +
           0.7152 * hdrImg[(k + hdrImg.size(0) * i) +
                           hdrImg.size(0) * hdrImg.size(1)]) +
          0.0722 * hdrImg[(k + hdrImg.size(0) * i) +
                          hdrImg.size(0) * hdrImg.size(1) * 2];
    }
  }
  nx = hdrImg.size(0) * hdrImg.size(1) * 3;
  b_hdrImg = hdrImg.reshape(nx);
  m = coder::internal::maximum(b_hdrImg);
  hdrPQ.set_size(hdrLum.size(0), hdrLum.size(1));
  loop_ub = hdrLum.size(0) * hdrLum.size(1);
  for (i = 0; i < loop_ub; i++) {
    e2 = hdrLum[i] / m;
    hdrPQ[i] = rt_powd_snf(e2, 0.1593017578125);
  }
  loop_ub = hdrPQ.size(0) * hdrPQ.size(1);
  for (i = 0; i < loop_ub; i++) {
    e2 = (18.8515625 * hdrPQ[i] + 0.8359375) / (18.6875 * hdrPQ[i] + 1.0);
    hdrPQ[i] = rt_powd_snf(e2, 78.84375);
  }
  //  y is input data
  //  nclust is the number of clusters or quantization levels. If you want to
  //  quantize data with b bits then nclust <= 2^b (256 if b=8)
  //  labels are the quantization intervals in [1, nclust] range assigned to y
  //  mdata is the mean value of each cluster
  lum.set_size(1, hdrLum.size(0) * hdrLum.size(1));
  loop_ub = hdrLum.size(0) * hdrLum.size(1);
  for (i = 0; i < loop_ub; i++) {
    lum[i] = hdrLum[i];
  }
  coder::internal::sort(lum);
  y.set_size(1, hdrPQ.size(0) * hdrPQ.size(1));
  loop_ub = hdrPQ.size(0) * hdrPQ.size(1);
  for (i = 0; i < loop_ub; i++) {
    y[i] = hdrPQ[i];
  }
  coder::internal::sort(y);
  varargin_1_idx_1 = static_cast<unsigned int>(y.size(1));
  s_data.set_size(1, y.size(1));
  loop_ub = y.size(1);
  for (i = 0; i < loop_ub; i++) {
    s_data[i] = y[i];
  }
  if ((y.size(1) != 0) && (y.size(1) != 1)) {
    i = y.size(1);
    for (k = 0; k <= i - 2; k++) {
      s_data[k + 1] = s_data[k] + s_data[k + 1];
    }
  }
  y.set_size(1, y.size(1));
  loop_ub = y.size(1) - 1;
  for (i = 0; i <= loop_ub; i++) {
    e2 = y[i];
    y[i] = e2 * e2;
  }
  if ((y.size(1) != 0) && (y.size(1) != 1)) {
    i = y.size(1);
    for (k = 0; k <= i - 2; k++) {
      y[k + 1] = y[k] + y[k + 1];
    }
  }
  n = y.size(1);
  loop_ub = y.size(1);
  edgesRes[0] = 0;
  edgesRes[2] = y.size(1);
  for (int b_i{0}; b_i < 54; b_i++) {
    unsigned int d;
    d = 2U;
    m = std::floor(static_cast<double>(varargin_1_idx_1) / 2.0);
    double e1;
    int exitg1;
    do {
      exitg1 = 0;
      minn = s_data[static_cast<int>(m) - 1];
      e2 = y[static_cast<int>(m) - 1];
      e1 = e2 - minn * minn / m;
      minn = s_data[n - 1] - minn;
      e2 = (y[n - 1] - e2) - minn * minn / (static_cast<double>(n) - m);
      d <<= 1;
      if ((std::abs(e1 - e2) < 0.001) || (d >= static_cast<unsigned int>(n))) {
        exitg1 = 1;
      } else if (e1 > e2) {
        m -= std::floor(static_cast<double>(n) / static_cast<double>(d));
      } else if (e1 < e2) {
        m += std::floor(static_cast<double>(n) / static_cast<double>(d));
      }
    } while (exitg1 == 0);
    if (static_cast<unsigned int>(m) + 1U > varargin_1_idx_1) {
      i = 0;
      k = 0;
    } else {
      i = static_cast<int>(static_cast<unsigned int>(m));
      k = static_cast<int>(varargin_1_idx_1);
    }
    b_lum.set_size(1, static_cast<int>(m));
    nx = static_cast<int>(m);
    for (int i1{0}; i1 < nx; i1++) {
      b_lum[i1] = lum[i1];
    }
    e2 = rt_powd_snf(10.0, tvi(std::log10(coder::median(b_lum))));
    nx = k - i;
    b_lum.set_size(1, nx);
    for (k = 0; k < nx; k++) {
      b_lum[k] = lum[i + k];
    }
    e2 = e2 / (e2 + rt_powd_snf(10.0, tvi(std::log10(coder::median(b_lum))))) *
             (lum[static_cast<int>(varargin_1_idx_1) - 1] - lum[0]) +
         lum[0];
    b_lum.set_size(1, loop_ub);
    for (i = 0; i < loop_ub; i++) {
      b_lum[i] = e2 - lum[i];
    }
    nx = b_lum.size(1);
    varargin_1.set_size(1, b_lum.size(1));
    for (k = 0; k < nx; k++) {
      varargin_1[k] = std::abs(b_lum[k]);
    }
    last = varargin_1.size(1);
    if (varargin_1.size(1) <= 2) {
      if (varargin_1.size(1) == 1) {
        nx = 1;
      } else if ((varargin_1[0] > varargin_1[varargin_1.size(1) - 1]) ||
                 (std::isnan(varargin_1[0]) &&
                  (!std::isnan(varargin_1[varargin_1.size(1) - 1])))) {
        nx = varargin_1.size(1);
      } else {
        nx = 1;
      }
    } else {
      if (!std::isnan(varargin_1[0])) {
        nx = 1;
      } else {
        boolean_T exitg2;
        nx = 0;
        k = 2;
        exitg2 = false;
        while ((!exitg2) && (k <= last)) {
          if (!std::isnan(varargin_1[k - 1])) {
            nx = k;
            exitg2 = true;
          } else {
            k++;
          }
        }
      }
      if (nx == 0) {
        nx = 1;
      } else {
        e2 = varargin_1[nx - 1];
        i = nx + 1;
        for (k = i; k <= last; k++) {
          minn = varargin_1[k - 1];
          if (e2 > minn) {
            e2 = minn;
            nx = k;
          }
        }
      }
    }
    edgesRes[1] = nx;
  }
  std::memset(&a__1[0], 0, 55U * sizeof(double));
  nx = hdrLum.size(0) * hdrLum.size(1);
  b_hdrImg = hdrLum.reshape(nx);
  a__1[0] = coder::internal::minimum(b_hdrImg);
  nx = hdrLum.size(0) * hdrLum.size(1);
  b_hdrImg = hdrLum.reshape(nx);
  a__1[54] = coder::internal::maximum(b_hdrImg);
  e2 = lum[edgesRes[2] - 1];
  for (int b_i{0}; b_i < 53; b_i++) {
    minn = lum[edgesRes[b_i + 1] - 1];
    if (minn == e2) {
      ind.set_size(hdrLum.size(0), hdrLum.size(1));
      loop_ub = hdrLum.size(0) * hdrLum.size(1);
      for (i = 0; i < loop_ub; i++) {
        ind[i] = (hdrLum[i] == minn);
      }
      last = ind.size(0) * ind.size(1) - 1;
      nx = 0;
      for (k = 0; k <= last; k++) {
        if (ind[k]) {
          nx++;
        }
      }
      r2.set_size(nx);
      nx = 0;
      for (k = 0; k <= last; k++) {
        if (ind[k]) {
          r2[nx] = k + 1;
          nx++;
        }
      }
      loop_ub = r2.size(0);
      matrix.set_size(r2.size(0));
      for (i = 0; i < loop_ub; i++) {
        matrix[i] = hdrLum[r2[i] - 1];
      }
      a__1[b_i + 1] = coder::mean(matrix) +
                      2.2204460492503131E-16 * (static_cast<double>(b_i) + 2.0);
    } else {
      ind.set_size(hdrLum.size(0), hdrLum.size(1));
      loop_ub = hdrLum.size(0) * hdrLum.size(1);
      for (i = 0; i < loop_ub; i++) {
        ind[i] = ((hdrLum[i] > minn) && (hdrLum[i] <= e2));
      }
      last = ind.size(0) * ind.size(1) - 1;
      nx = 0;
      for (k = 0; k <= last; k++) {
        if (ind[k]) {
          nx++;
        }
      }
      r3.set_size(nx);
      nx = 0;
      for (k = 0; k <= last; k++) {
        if (ind[k]) {
          r3[nx] = k + 1;
          nx++;
        }
      }
      loop_ub = r3.size(0);
      matrix.set_size(r3.size(0));
      for (i = 0; i < loop_ub; i++) {
        matrix[i] = hdrLum[r3[i] - 1];
      }
      a__1[b_i + 1] = coder::mean(matrix);
    }
  }
  coder::interp1(a__1, hdrLum, labels_DoG);
  //  local enhancemant using DoG
  nx = hdrPQ.size(0) * hdrPQ.size(1);
  b_hdrImg = hdrPQ.reshape(nx);
  minn = coder::internal::minimum(b_hdrImg);
  nx = hdrPQ.size(0) * hdrPQ.size(1);
  b_hdrImg = hdrPQ.reshape(nx);
  m = coder::internal::maximum(b_hdrImg);
  nx = hdrPQ.size(0) * hdrPQ.size(1);
  b_hdrImg = hdrPQ.reshape(nx);
  e2 = coder::internal::minimum(b_hdrImg);
  if ((hdrPQ.size(0) == labels_DoG.size(0)) &&
      (hdrPQ.size(1) == labels_DoG.size(1))) {
    m -= e2;
    loop_ub = hdrPQ.size(0) * hdrPQ.size(1);
    for (i = 0; i < loop_ub; i++) {
      hdrPQ[i] =
          (255.0 * (hdrPQ[i] - minn) / m + 1.0) * 0.35 + labels_DoG[i] * 0.65;
    }
  } else {
    binary_expand_op(hdrPQ, minn, m, e2, labels_DoG);
  }
  coder::imfilter(hdrPQ);
  if ((labels_DoG.size(0) == hdrPQ.size(0)) &&
      (labels_DoG.size(1) == hdrPQ.size(1))) {
    loop_ub = labels_DoG.size(0) * labels_DoG.size(1);
    for (i = 0; i < loop_ub; i++) {
      labels_DoG[i] = labels_DoG[i] + 3.0 * hdrPQ[i];
    }
  } else {
    binary_expand_op(labels_DoG, hdrPQ);
  }
  //  color restoration
  nx = labels_DoG.size(0) * labels_DoG.size(1);
  b_hdrImg = labels_DoG.reshape(nx);
  minn = coder::internal::minimum(b_hdrImg);
  nx = labels_DoG.size(0) * labels_DoG.size(1);
  b_hdrImg = labels_DoG.reshape(nx);
  m = coder::internal::maximum(b_hdrImg);
  nx = labels_DoG.size(0) * labels_DoG.size(1);
  hdrPQ.set_size(labels_DoG.size(0), labels_DoG.size(1));
  b_hdrImg = labels_DoG.reshape(nx);
  m -= coder::internal::minimum(b_hdrImg);
  loop_ub = labels_DoG.size(0) * labels_DoG.size(1);
  for (i = 0; i < loop_ub; i++) {
    hdrPQ[i] = (labels_DoG[i] - minn) / m;
  }
  nx = hdrPQ.size(0) * hdrPQ.size(1);
  for (k = 0; k < nx; k++) {
    hdrPQ[k] = std::atan(hdrPQ[k]);
  }
  loop_ub = hdrPQ.size(0) * hdrPQ.size(1);
  for (i = 0; i < loop_ub; i++) {
    e2 = 1.0 - hdrPQ[i];
    hdrPQ[i] = std::fmin(e2, 0.5);
  }
  if ((hdrImg.size(0) == hdrLum.size(0)) &&
      (hdrImg.size(1) == hdrLum.size(1))) {
    last = hdrLum.size(0);
    c_hdrImg.set_size(hdrImg.size(0), hdrImg.size(1), 3);
    loop_ub = hdrImg.size(1);
    for (i = 0; i < 3; i++) {
      for (k = 0; k < loop_ub; k++) {
        nx = hdrImg.size(0);
        for (int i1{0}; i1 < nx; i1++) {
          c_hdrImg[(i1 + c_hdrImg.size(0) * k) +
                   c_hdrImg.size(0) * c_hdrImg.size(1) * i] =
              hdrImg[(i1 + hdrImg.size(0) * k) +
                     hdrImg.size(0) * hdrImg.size(1) * i] /
              hdrLum[i1 + last * k];
        }
      }
    }
    coder::internal::expand_power(c_hdrImg, hdrPQ, ldrImg);
  } else {
    binary_expand_op(ldrImg, hdrImg, hdrLum, hdrPQ);
  }
  if ((ldrImg.size(0) == labels_DoG.size(0)) &&
      (ldrImg.size(1) == labels_DoG.size(1))) {
    last = labels_DoG.size(0);
    c_hdrImg.set_size(ldrImg.size(0), ldrImg.size(1), 3);
    loop_ub = ldrImg.size(1);
    for (i = 0; i < 3; i++) {
      for (k = 0; k < loop_ub; k++) {
        nx = ldrImg.size(0);
        for (int i1{0}; i1 < nx; i1++) {
          c_hdrImg[(i1 + c_hdrImg.size(0) * k) +
                   c_hdrImg.size(0) * c_hdrImg.size(1) * i] =
              ldrImg[(i1 + ldrImg.size(0) * k) +
                     ldrImg.size(0) * ldrImg.size(1) * i] *
              labels_DoG[i1 + last * k];
        }
      }
    }
    ldrImg.set_size(c_hdrImg.size(0), c_hdrImg.size(1), 3);
    loop_ub = c_hdrImg.size(0) * c_hdrImg.size(1) * 3;
    for (i = 0; i < loop_ub; i++) {
      ldrImg[i] = c_hdrImg[i];
    }
  } else {
    binary_expand_op(ldrImg, labels_DoG);
  }
  //
  //        ret = MaxQuart(matrix, percentile)
  //
  //        Input:
  //            -matrix: a matrix
  //            -percentile: a value in the range [0,1]
  //
  //        Output:
  //            -ret: the percentile of the input matrix
  //
  //      Copyright (C) 2011-2015  Francesco Banterle
  //
  //      This program is free software: you can redistribute it and/or modify
  //      it under the terms of the GNU General Public License as published by
  //      the Free Software Foundation, either version 3 of the License, or
  //      (at your option) any later version.
  //
  //      This program is distributed in the hope that it will be useful,
  //      but WITHOUT ANY WARRANTY; without even the implied warranty of
  //      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  //      GNU General Public License for more details.
  //
  //      You should have received a copy of the GNU General Public License
  //      along with this program.  If not, see <http://www.gnu.org/licenses/>.
  //
  matrix.set_size(ldrImg.size(0) * ldrImg.size(1) * 3);
  loop_ub = ldrImg.size(0) * ldrImg.size(1) * 3;
  for (i = 0; i < loop_ub; i++) {
    matrix[i] = ldrImg[i];
  }
  coder::internal::sort(matrix);
  i = static_cast<int>(std::round(
      static_cast<double>(ldrImg.size(0) * ldrImg.size(1) * 3) * 0.99));
  if (i < 1) {
    i = 1;
  }
  e2 = matrix[i - 1];
  //
  //        ret = MaxQuart(matrix, percentile)
  //
  //        Input:
  //            -matrix: a matrix
  //            -percentile: a value in the range [0,1]
  //
  //        Output:
  //            -ret: the percentile of the input matrix
  //
  //      Copyright (C) 2011-2015  Francesco Banterle
  //
  //      This program is free software: you can redistribute it and/or modify
  //      it under the terms of the GNU General Public License as published by
  //      the Free Software Foundation, either version 3 of the License, or
  //      (at your option) any later version.
  //
  //      This program is distributed in the hope that it will be useful,
  //      but WITHOUT ANY WARRANTY; without even the implied warranty of
  //      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  //      GNU General Public License for more details.
  //
  //      You should have received a copy of the GNU General Public License
  //      along with this program.  If not, see <http://www.gnu.org/licenses/>.
  //
  matrix.set_size(ldrImg.size(0) * ldrImg.size(1) * 3);
  loop_ub = ldrImg.size(0) * ldrImg.size(1) * 3;
  for (i = 0; i < loop_ub; i++) {
    matrix[i] = ldrImg[i];
  }
  coder::internal::sort(matrix);
  i = static_cast<int>(std::round(
      static_cast<double>(ldrImg.size(0) * ldrImg.size(1) * 3) * 0.01));
  if (i < 1) {
    i = 1;
  }
  minn = matrix[i - 1];
  if (e2 < 255.0) {
    nx = ldrImg.size(0) * ldrImg.size(1) * 3;
    b_hdrImg = ldrImg.reshape(nx);
    if (coder::internal::maximum(b_hdrImg) < 255.0) {
      nx = ldrImg.size(0) * ldrImg.size(1) * 3;
      b_hdrImg = ldrImg.reshape(nx);
      e2 = coder::internal::maximum(b_hdrImg);
    } else {
      e2 = 255.0;
    }
  }
  if (minn > 0.0) {
    nx = ldrImg.size(0) * ldrImg.size(1) * 3;
    b_hdrImg = ldrImg.reshape(nx);
    if (coder::internal::minimum(b_hdrImg) > 0.0) {
      nx = ldrImg.size(0) * ldrImg.size(1) * 3;
      b_hdrImg = ldrImg.reshape(nx);
      minn = coder::internal::minimum(b_hdrImg);
    } else {
      minn = 0.0;
    }
  }
  last = ldrImg.size(0) * (ldrImg.size(1) * 3) - 1;
  nx = 0;
  for (int b_i{0}; b_i <= last; b_i++) {
    if (ldrImg[b_i] > e2) {
      nx++;
    }
  }
  r4.set_size(nx);
  nx = 0;
  for (int b_i{0}; b_i <= last; b_i++) {
    if (ldrImg[b_i] > e2) {
      r4[nx] = b_i + 1;
      nx++;
    }
  }
  loop_ub = r4.size(0);
  for (i = 0; i < loop_ub; i++) {
    ldrImg[r4[i] - 1] = e2;
  }
  last = ldrImg.size(0) * (ldrImg.size(1) * 3) - 1;
  nx = 0;
  for (int b_i{0}; b_i <= last; b_i++) {
    if (ldrImg[b_i] < minn) {
      nx++;
    }
  }
  r5.set_size(nx);
  nx = 0;
  for (int b_i{0}; b_i <= last; b_i++) {
    if (ldrImg[b_i] < minn) {
      r5[nx] = b_i + 1;
      nx++;
    }
  }
  loop_ub = r5.size(0);
  for (i = 0; i < loop_ub; i++) {
    ldrImg[r5[i] - 1] = minn;
  }
  loop_ub = ldrImg.size(0) * ldrImg.size(1) * 3;
  ldrImg.set_size(ldrImg.size(0), ldrImg.size(1), 3);
  e2 -= minn;
  for (i = 0; i < loop_ub; i++) {
    ldrImg[i] = 255.0 * ((ldrImg[i] - minn) / e2);
  }
}

//
// Arguments    : void
// Return Type  : void
//
void DCA_TMO_initialize()
{
  omp_init_nest_lock(&DCA_TMO_nestLockGlobal);
  isInitialized_DCA_TMO = true;
}

//
// Arguments    : void
// Return Type  : void
//
void DCA_TMO_terminate()
{
  omp_destroy_nest_lock(&DCA_TMO_nestLockGlobal);
  isInitialized_DCA_TMO = false;
}

//
// File trailer for DCA_TMO.cpp
//
// [EOF]
//
