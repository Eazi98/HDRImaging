/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: interp1.c
 *
 * MATLAB Coder version            : 5.5
 * C/C++ source code generated on  : 13-Jan-2023 11:41:44
 */

/* Include Files */
#include "interp1.h"
#include "DCA_TMO_emxutil.h"
#include "DCA_TMO_types.h"
#include "rt_nonfinite.h"
#include "omp.h"
#include "rt_nonfinite.h"

/* Function Declarations */
static void interp1Linear(const double y[55], const emxArray_real_T *xi,
                          emxArray_real_T *yi, const double varargin_1[55]);

/* Function Definitions */
/*
 * Arguments    : const double y[55]
 *                const emxArray_real_T *xi
 *                emxArray_real_T *yi
 *                const double varargin_1[55]
 * Return Type  : void
 */
static void interp1Linear(const double y[55], const emxArray_real_T *xi,
                          emxArray_real_T *yi, const double varargin_1[55])
{
  const double *xi_data;
  double d;
  double maxx;
  double minx;
  double r;
  double *yi_data;
  int high_i;
  int k;
  int low_i;
  int low_ip1;
  int mid_i;
  int ub_loop;
  yi_data = yi->data;
  xi_data = xi->data;
  minx = varargin_1[0];
  maxx = varargin_1[54];
  ub_loop = xi->size[0] * xi->size[1] - 1;
#pragma omp parallel for num_threads(omp_get_max_threads()) private(           \
    low_i, low_ip1, high_i, r, mid_i, d)

  for (k = 0; k <= ub_loop; k++) {
    if (rtIsNaN(xi_data[k])) {
      yi_data[k] = rtNaN;
    } else if ((!(xi_data[k] > maxx)) && (!(xi_data[k] < minx))) {
      low_i = 1;
      low_ip1 = 2;
      high_i = 55;
      while (high_i > low_ip1) {
        mid_i = (low_i + high_i) >> 1;
        if (xi_data[k] >= varargin_1[mid_i - 1]) {
          low_i = mid_i;
          low_ip1 = mid_i + 1;
        } else {
          high_i = mid_i;
        }
      }
      r = varargin_1[low_i - 1];
      r = (xi_data[k] - r) / (varargin_1[low_i] - r);
      if (r == 0.0) {
        yi_data[k] = y[low_i - 1];
      } else if (r == 1.0) {
        yi_data[k] = y[low_i];
      } else {
        d = y[low_i - 1];
        if (d == y[low_i]) {
          yi_data[k] = d;
        } else {
          yi_data[k] = (1.0 - r) * d + r * y[low_i];
        }
      }
    }
  }
}

/*
 * Arguments    : const double varargin_1[55]
 *                const emxArray_real_T *varargin_3
 *                emxArray_real_T *Vq
 * Return Type  : void
 */
void interp1(const double varargin_1[55], const emxArray_real_T *varargin_3,
             emxArray_real_T *Vq)
{
  double x[55];
  double y[55];
  double *Vq_data;
  int i;
  int loop_ub;
  boolean_T b;
  boolean_T b1;
  for (i = 0; i < 55; i++) {
    x[i] = varargin_1[i];
    y[i] = 4.7222222222222223 * (double)i + 1.0;
  }
  i = Vq->size[0] * Vq->size[1];
  Vq->size[0] = varargin_3->size[0];
  Vq->size[1] = varargin_3->size[1];
  emxEnsureCapacity_real_T(Vq, i);
  Vq_data = Vq->data;
  loop_ub = varargin_3->size[0] * varargin_3->size[1];
  for (i = 0; i < loop_ub; i++) {
    Vq_data[i] = rtNaN;
  }
  b = (varargin_3->size[0] == 0);
  b1 = (varargin_3->size[1] == 0);
  if ((!b) && (!b1)) {
    loop_ub = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (loop_ub < 55) {
        if (rtIsNaN(varargin_1[loop_ub])) {
          exitg1 = 1;
        } else {
          loop_ub++;
        }
      } else {
        if (varargin_1[1] < varargin_1[0]) {
          for (loop_ub = 0; loop_ub < 27; loop_ub++) {
            double xtmp;
            xtmp = x[loop_ub];
            x[loop_ub] = x[54 - loop_ub];
            x[54 - loop_ub] = xtmp;
            xtmp = y[loop_ub];
            y[loop_ub] = y[54 - loop_ub];
            y[54 - loop_ub] = xtmp;
          }
        }
        interp1Linear(y, varargin_3, Vq, x);
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
}

/*
 * File trailer for interp1.c
 *
 * [EOF]
 */
